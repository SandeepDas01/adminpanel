-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 20, 2021 at 08:00 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `model`
--

-- --------------------------------------------------------

--
-- Table structure for table `agency`
--

CREATE TABLE IF NOT EXISTS `agency` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `a_code` int(200) NOT NULL,
  `a_email` varchar(200) NOT NULL,
  `a_password` varchar(200) NOT NULL,
  `a_name` varchar(200) NOT NULL,
  `a_countrry` varchar(200) NOT NULL,
  `a_contactpersonname` varchar(200) NOT NULL,
  `a_modelswhere` varchar(200) NOT NULL,
  `a_status` int(11) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `agency`
--

INSERT INTO `agency` (`a_id`, `a_code`, `a_email`, `a_password`, `a_name`, `a_countrry`, `a_contactpersonname`, `a_modelswhere`, `a_status`) VALUES
(1, 0, 'dassandeep0001@gmail.com', 'sandeep@123', 'your model', 'India', 'sandeep', 'International', 1),
(2, 1, 'bhai@gmail.com', '12345', 'Sunny', 'Pakistan', 'Hamaz', 'International', 1);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `uc_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=133 ;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`c_id`, `u_id`, `view`, `uc_status`) VALUES
(1, 271, 1391, 1),
(2, 2341, 1407, 1),
(3, 2342, 1268, 1),
(4, 2343, 1259, 1),
(5, 2344, 1254, 1),
(6, 2345, 1266, 1),
(7, 2346, 1257, 1),
(8, 2347, 1266, 1),
(9, 911, 1493, 1),
(10, 912, 1361, 1),
(11, 913, 1258, 1),
(12, 2348, 1242, 1),
(13, 2349, 1250, 1),
(14, 23410, 1262, 1),
(15, 23411, 1309, 1),
(16, 23412, 1244, 1),
(17, 914, 1363, 1),
(18, 23413, 1250, 1),
(19, 23414, 1320, 1),
(20, 915, 1599, 1),
(21, 272, 1242, 1),
(22, 23415, 1279, 1),
(23, 23416, 1252, 1),
(24, 916, 1265, 1),
(27, 23418, 1239, 1),
(26, 23417, 1289, 1),
(28, 910897, 1238, 1),
(29, 273, 1240, 1),
(30, 922, 1290, 1),
(32, 917, 1276, 1),
(33, 910898, 1243, 1),
(34, 918, 1805, 1),
(35, 919, 1275, 1),
(36, 9110, 1252, 1),
(37, 9111, 1255, 1),
(38, 23419, 1267, 1),
(39, 274, 1244, 1),
(40, 9112, 1315, 1),
(41, 11, 1318, 1),
(42, 23420, 1261, 1),
(43, 910899, 1337, 1),
(44, 9113, 1243, 1),
(45, 9114, 1402, 1),
(46, 9115, 1242, 1),
(47, 9116, 1248, 1),
(48, 275, 1375, 1),
(49, 23421, 1315, 1),
(50, 12, 1242, 1),
(51, 923, 1267, 1),
(52, 924, 1387, 1),
(53, 9117, 1351, 1),
(54, 23422, 1245, 1),
(55, 971, 1269, 1),
(56, 9118, 1359, 1),
(57, 9119, 1243, 1),
(58, 9711, 1249, 1),
(59, 9712, 1308, 1),
(60, 9120, 1247, 1),
(61, 9121, 1281, 1),
(62, 9122, 1257, 1),
(63, 9108100, 1252, 1),
(64, 9713, 1242, 1),
(65, 9123, 1249, 1),
(66, 9714, 1271, 1),
(67, 925, 1385, 1),
(68, 9124, 1243, 1),
(69, 9125, 1269, 1),
(70, 9715, 1268, 1),
(71, 9126, 1244, 1),
(72, 926, 1265, 1),
(73, 9127, 1264, 1),
(74, 9128, 1243, 1),
(75, 23424, 1249, 1),
(76, 9129, 1271, 1),
(77, 9130, 1260, 1),
(78, 9131, 1247, 1),
(79, 9716, 1264, 1),
(80, 927, 1326, 1),
(81, 9132, 1239, 1),
(82, 2111, 1240, 1),
(83, 9108101, 1241, 1),
(84, 9133, 1270, 1),
(85, 9108102, 1262, 1),
(86, 9134, 1238, 1),
(87, 9135, 1301, 1),
(88, 928, 1368, 1),
(89, 9137, 1282, 1),
(90, 2301, 1353, 1),
(91, 9138, 1268, 1),
(92, 9139, 1269, 1),
(93, 9717, 1387, 1),
(94, 23426, 1260, 1),
(95, 23427, 1245, 1),
(96, 23428, 1244, 1),
(97, 929, 1251, 1),
(98, 9108103, 1257, 1),
(99, 9140, 1247, 1),
(100, 23429, 1241, 1),
(101, 277, 1240, 1),
(102, 9210, 1241, 1),
(103, 9211, 1310, 1),
(104, 9108104, 70, 1),
(105, 9108105, 9, 1),
(106, 9212, 1321, 1),
(107, 9213, 1250, 1),
(108, 9718, 1262, 1),
(109, 23430, 1253, 1),
(110, 9141, 1336, 1),
(111, 9142, 1248, 1),
(112, 278, 1251, 1),
(113, 9143, 1240, 1),
(114, 9719, 1241, 1),
(115, 9720, 1259, 1),
(116, 261, 1239, 1),
(117, 9144, 1264, 1),
(118, 279, 1245, 1),
(119, 9145, 1247, 1),
(120, 9146, 1243, 1),
(121, 2541, 1246, 1),
(122, 9108106, 1267, 1),
(123, 2711, 1242, 1),
(124, 23431, 1248, 1),
(125, 9108107, 1285, 1),
(126, 9147, 1269, 1),
(127, 9149, 1240, 1),
(128, 9150, 1256, 1),
(129, 9150, 1254, 1),
(130, 9108108, 1239, 1),
(131, 9151, 1247, 1),
(132, 9108109, 1240, 1);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `c_code` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `c_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`c_id`, `c_name`, `c_code`, `c_status`) VALUES
(1, 'India', '+91', 1),
(2, 'Pakistan', '+92', 1),
(3, 'Nigeria ', '+234', 1),
(4, 'Usa', '+1', 1),
(5, 'Dubai', '+971', 1),
(6, 'South Africa', '+27', 1),
(7, 'Uae', '+971', 1),
(8, 'Nepal', '+977', 1),
(9, 'South Sudan', '211', 1),
(10, 'Mauritius', '230', 1),
(11, 'botswana', '26', 1),
(12, 'Kenya ', '254', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hiring`
--

CREATE TABLE IF NOT EXISTS `hiring` (
  `h_id` int(200) NOT NULL AUTO_INCREMENT,
  `model_id` varchar(200) NOT NULL,
  `h_name` varchar(200) NOT NULL,
  `h_whatsappnumber` varchar(200) NOT NULL,
  `h_production` varchar(200) NOT NULL,
  `h_director` varchar(200) NOT NULL,
  `h_producer` varchar(200) NOT NULL,
  `pay` varchar(200) NOT NULL,
  `ourrate` varchar(200) NOT NULL,
  `h_description` varchar(200) NOT NULL,
  `h_date` varchar(5000) NOT NULL,
  `h_status` int(200) NOT NULL,
  PRIMARY KEY (`h_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hiring`
--

INSERT INTO `hiring` (`h_id`, `model_id`, `h_name`, `h_whatsappnumber`, `h_production`, `h_director`, `h_producer`, `pay`, `ourrate`, `h_description`, `h_date`, `h_status`) VALUES
(1, '9108114', 'Rahul Roy', '8697990096', 'Cine care production', 'Mahindra sinh', 'Souvik dad', '', '', 'Nude shoot for magazine.Release will be out of country.8days shoot/180k payment.location -,kolkata', '2020-06-19 20:17:29', 0),
(2, '9108107', 'sandeeo', '56', 'df', 'dcfvb', 'dfg', '12000', '', 'dfghj', '2020-06-20 09:01:41', 0),
(3, '9108104', 'Umair', '+923132492994', 'Elite films', 'Zoya Ali khan', 'Zoya', '50000', '', 'We need model ', '2020-06-21 07:18:30', 0);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_code` int(11) NOT NULL,
  `big_image` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image1` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image2` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image3` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image4` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image5` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image6` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image7` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image8` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image9` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=138 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`i_id`, `u_code`, `big_image`, `image1`, `image2`, `image3`, `image4`, `image5`, `image6`, `image7`, `image8`, `image9`, `status`) VALUES
(1, 2341, 'assets/uploader/image2341B.jpeg', 'assets/uploader/image23411.jpg', 'assets/uploader/image234110.jpg', 'assets/uploader/image234111.jpg', 'assets/uploader/image23412.jpg', 'assets/uploader/image23413.jpg', 'assets/uploader/image23414.jpg', 'assets/uploader/image23415.jpg', 'assets/uploader/image23416.jpg', 'assets/uploader/image23417.jpg', 1),
(2, 271, 'assets/uploader/image271b.jpeg', 'assets/uploader/image2711.jpeg', 'assets/uploader/image2712.jpeg', 'assets/uploader/image2713.jpeg', 'assets/uploader/image2714.jpeg', 'assets/uploader/image2715.jpeg', 'assets/uploader/image2716.jpeg', 'assets/uploader/image2717.jpeg', 'assets/uploader/image2718.jpeg', 'assets/uploader/image2719.jpeg', 1),
(3, 2342, 'assets/uploader/image2342B.jpeg', 'assets/uploader/image23421.jpeg', 'assets/uploader/image23422.jpeg', 'assets/uploader/image23423.jpeg', 'assets/uploader/image23424.jpeg', 'assets/uploader/image23425.jpeg', 'assets/uploader/image23426.jpeg', 'assets/uploader/image23427.jpeg', 'assets/uploader/image23428.jpeg', 'assets/uploader/image23429.jpeg', 1),
(4, 2343, 'assets/uploader/image2343b.jpeg', 'assets/uploader/image23431.jpeg', 'assets/uploader/image23432.jpeg', 'assets/uploader/image23433.jpeg', 'assets/uploader/image23434.jpeg', 'assets/uploader/image2343b.jpeg', 'assets/uploader/image23435.jpeg', 'assets/uploader/image23436.jpeg', 'assets/uploader/image23437.jpeg', 'assets/uploader/image23432.jpeg', 1),
(5, 2344, 'assets/uploader/image2344b.jpeg', 'assets/uploader/image23441.jpeg', 'assets/uploader/image23442.jpeg', 'assets/uploader/image23443.jpeg', 'assets/uploader/image23444.jpeg', 'assets/uploader/image23445.jpeg', 'assets/uploader/image23446.jpeg', 'assets/uploader/image23447.jpeg', 'assets/uploader/image23448.jpeg', 'assets/uploader/image23449.jpeg', 1),
(6, 2345, 'assets/uploader/image2345b.jpeg', 'assets/uploader/image23451.jpeg', 'assets/uploader/image23452.jpeg', 'assets/uploader/image23453.jpeg', 'assets/uploader/image23454.jpeg', 'assets/uploader/image23455.jpeg', 'assets/uploader/image23456.jpeg', 'assets/uploader/image23457.jpeg', 'assets/uploader/image23458.jpeg', 'assets/uploader/image23459.jpeg', 1),
(7, 2346, 'assets/uploader/image2346b.jpeg', 'assets/uploader/image23461.jpeg', 'assets/uploader/image23462.jpeg', 'assets/uploader/image23463.jpeg', 'assets/uploader/image23464.jpeg', 'assets/uploader/image23465.jpeg', 'assets/uploader/image23466.jpeg', 'assets/uploader/image23467.jpeg', 'assets/uploader/image23468.jpeg', 'assets/uploader/image2346b.jpeg', 1),
(8, 2347, 'assets/uploader/image2347b.jpeg', 'assets/uploader/image23471.jpeg', 'assets/uploader/image23472.jpeg', 'assets/uploader/image23473.jpeg', 'assets/uploader/image23474.jpeg', 'assets/uploader/image23475.jpeg', 'assets/uploader/image23476.jpeg', 'assets/uploader/image23472.jpeg', 'assets/uploader/image2347b.jpeg', 'assets/uploader/image23474.jpeg', 1),
(9, 911, 'assets/uploader/image911b.jpeg', 'assets/uploader/image9111.jpeg', 'assets/uploader/image9112.jpeg', 'assets/uploader/image9113.jpeg', 'assets/uploader/image9114.jpeg', 'assets/uploader/image9115.jpeg', 'assets/uploader/image9116.jpeg', 'assets/uploader/image9117.jpeg', 'assets/uploader/image9118.jpeg', 'assets/uploader/image9119.jpeg', 1),
(10, 912, 'assets/uploader/image912b.jpeg', 'assets/uploader/image9121.jpeg', 'assets/uploader/image9122.jpeg', 'assets/uploader/image9123.jpeg', 'assets/uploader/image9124.jpeg', 'assets/uploader/image9125.jpeg', 'assets/uploader/image9126.jpeg', 'assets/uploader/image9127.jpeg', 'assets/uploader/image9128.jpeg', 'assets/uploader/image9129.jpeg', 1),
(11, 913, 'assets/uploader/image913b.jpeg', 'assets/uploader/image9131.jpeg', 'assets/uploader/image9132.jpeg', 'assets/uploader/image9133.jpeg', 'assets/uploader/image9134.jpeg', 'assets/uploader/image9135.jpeg', 'assets/uploader/image9136.jpeg', 'assets/uploader/image9137.jpeg', 'assets/uploader/image9138.jpeg', 'assets/uploader/image9139.jpeg', 1),
(12, 2348, 'assets/uploader/image2348b.jpeg', 'assets/uploader/image23481.jpeg', 'assets/uploader/image23482.jpeg', 'assets/uploader/image23483.jpeg', 'assets/uploader/image23484.jpeg', 'assets/uploader/image23485.jpeg', 'assets/uploader/image23486.jpeg', 'assets/uploader/image23487.jpeg', 'assets/uploader/image23488.jpeg', 'assets/uploader/image2348b.jpeg', 1),
(13, 2349, 'assets/uploader/image2349b.jpeg', 'assets/uploader/image23491.jpeg', 'assets/uploader/image23492.jpeg', 'assets/uploader/image23493.jpeg', 'assets/uploader/image23494.jpeg', 'assets/uploader/image2349b.jpeg', 'assets/uploader/image23495.jpeg', 'assets/uploader/image23496.jpeg', 'assets/uploader/image23497.jpeg', 'assets/uploader/image23493.jpeg', 1),
(14, 23410, 'assets/uploader/image23410b.jpeg', 'assets/uploader/image234106.jpeg', 'assets/uploader/image234101.jpeg', 'assets/uploader/image234102.jpeg', 'assets/uploader/image234103.jpeg', 'assets/uploader/image234104.jpeg', 'assets/uploader/image234105.jpeg', 'assets/uploader/image234106.jpeg', 'assets/uploader/image234107.jpeg', 'assets/uploader/image234103.jpeg', 1),
(15, 23411, 'assets/uploader/image23411b.jpeg', 'assets/uploader/image234111.jpeg', 'assets/uploader/image234112.jpeg', 'assets/uploader/image234113.jpeg', 'assets/uploader/image234114.jpeg', 'assets/uploader/image234115.jpeg', 'assets/uploader/image234116.jpeg', 'assets/uploader/image234117.jpeg', 'assets/uploader/image234118.jpeg', 'assets/uploader/image234119.jpeg', 1),
(16, 23412, 'assets/uploader/image23412b.jpeg', 'assets/uploader/image234121.jpeg', 'assets/uploader/image234122.jpeg', 'assets/uploader/image234123.jpeg', 'assets/uploader/image234124.jpeg', 'assets/uploader/image234125.jpeg', 'assets/uploader/image234126.jpeg', 'assets/uploader/image234127.jpeg', 'assets/uploader/image234128.jpeg', 'assets/uploader/image234129.jpeg', 1),
(17, 914, 'assets/uploader/image914b.jpeg', 'assets/uploader/image9141.jpeg', 'assets/uploader/image9142.jpeg', 'assets/uploader/image9143.jpeg', 'assets/uploader/image9144.jpeg', 'assets/uploader/image9145.jpeg', 'assets/uploader/image9146.jpeg', 'assets/uploader/image9147.jpeg', 'assets/uploader/image9148.jpeg', 'assets/uploader/image9149.jpeg', 1),
(18, 23413, 'assets/uploader/image23413b.jpeg', 'assets/uploader/image234131.jpeg', 'assets/uploader/image234132.jpeg', 'assets/uploader/image234133.jpeg', 'assets/uploader/image234134.jpeg', 'assets/uploader/image234135.jpeg', 'assets/uploader/image234136.jpeg', 'assets/uploader/image234137.jpeg', 'assets/uploader/image234138.jpeg', 'assets/uploader/image234139.jpeg', 1),
(19, 23414, 'assets/uploader/image23414b.jpeg', 'assets/uploader/image234142.jpeg', 'assets/uploader/image234143.jpeg', 'assets/uploader/image234144.jpeg', 'assets/uploader/image234145.jpeg', 'assets/uploader/image234146.jpeg', 'assets/uploader/image234147.jpeg', 'assets/uploader/image234148.jpeg', 'assets/uploader/image234149.jpeg', 'assets/uploader/image23414b.jpeg', 1),
(20, 915, 'assets/uploader/image915b.jpeg', 'assets/uploader/image9151.jpeg', 'assets/uploader/image9152.jpeg', 'assets/uploader/image9153.jpeg', 'assets/uploader/image9154.jpeg', 'assets/uploader/image9155.jpeg', 'assets/uploader/image9156.jpeg', 'assets/uploader/image915b.jpeg', 'assets/uploader/image9157.jpeg', 'assets/uploader/image9158.jpeg', 1),
(21, 272, 'assets/uploader/image272b.jpeg', 'assets/uploader/image2721.jpeg', 'assets/uploader/image2722.jpeg', 'assets/uploader/image2723.jpeg', 'assets/uploader/image2724.jpeg', 'assets/uploader/image2725.jpeg', 'assets/uploader/image2726.jpeg', 'assets/uploader/image2727.jpeg', 'assets/uploader/image2728.jpeg', 'assets/uploader/image2729.jpeg', 1),
(22, 23415, 'assets/uploader/image23415b.jpeg', 'assets/uploader/image234151.jpeg', 'assets/uploader/image234152.jpeg', 'assets/uploader/image234153.jpeg', 'assets/uploader/image234154.jpeg', 'assets/uploader/image234155.jpeg', 'assets/uploader/image234156.jpeg', 'assets/uploader/image234157.jpeg', 'assets/uploader/image23415b.jpeg', 'assets/uploader/image234154.jpeg', 1),
(23, 23416, 'assets/uploader/image23416b.jpeg', 'assets/uploader/image234161.jpeg', 'assets/uploader/image234162.jpeg', 'assets/uploader/image234163.jpeg', 'assets/uploader/image234164.jpeg', 'assets/uploader/image234165.jpeg', 'assets/uploader/image234166.jpeg', 'assets/uploader/image234167.jpeg', 'assets/uploader/image234162.jpeg', 'assets/uploader/image23416b.jpeg', 1),
(24, 916, 'assets/uploader/image916b.jpeg', 'assets/uploader/image9161.jpeg', 'assets/uploader/image9162.jpeg', 'assets/uploader/image9163.jpeg', 'assets/uploader/image9164.jpeg', 'assets/uploader/image9165.jpeg', 'assets/uploader/image9166.jpeg', 'assets/uploader/image9167.jpeg', 'assets/uploader/image9168.jpeg', 'assets/uploader/image9169.jpeg', 1),
(27, 23418, 'assets/uploader/image23418b.jpeg', 'assets/uploader/image234181.jpeg', 'assets/uploader/image234182.jpeg', 'assets/uploader/image234183.jpeg', 'assets/uploader/image234184.jpeg', 'assets/uploader/image234185.jpeg', 'assets/uploader/image234186.jpeg', 'assets/uploader/image234187.jpeg', 'assets/uploader/image234188.jpeg', 'assets/uploader/image234189.jpeg', 1),
(26, 23417, 'assets/uploader/image23417b.jpeg', 'assets/uploader/image234171.jpeg', 'assets/uploader/image234172.jpeg', 'assets/uploader/image234173.jpeg', 'assets/uploader/image234174.jpeg', 'assets/uploader/image234175.jpeg', 'assets/uploader/image234176.jpeg', 'assets/uploader/image234177.jpeg', 'assets/uploader/image234178.jpeg', 'assets/uploader/image234179.jpeg', 1),
(28, 910897, 'assets/uploader/image910897b.jpeg', 'assets/uploader/image9108971.jpeg', 'assets/uploader/image9108972.jpeg', 'assets/uploader/image9108973.jpeg', 'assets/uploader/image9108974.jpeg', 'assets/uploader/image9108975.jpeg', 'assets/uploader/image9108975.jpeg', 'assets/uploader/image9108977.jpeg', 'assets/uploader/image9108978.jpeg', 'assets/uploader/image9108979.jpeg', 1),
(29, 273, 'assets/uploader/image273b.jpeg', 'assets/uploader/image2731.jpeg', 'assets/uploader/image2732.jpeg', 'assets/uploader/image2733.jpeg', 'assets/uploader/image2734.jpeg', 'assets/uploader/image2735.jpeg', 'assets/uploader/image2736.jpeg', 'assets/uploader/image2737.jpeg', 'assets/uploader/image2738.jpeg', 'assets/uploader/image2739.jpeg', 1),
(30, 922, 'assets/uploader/image922b.jpeg', 'assets/uploader/image9221.jpeg', 'assets/uploader/image9222.jpeg', 'assets/uploader/image9223.jpeg', 'assets/uploader/image9224.jpeg', 'assets/uploader/image9225.jpeg', 'assets/uploader/image9226.jpeg', 'assets/uploader/image9227.jpeg', 'assets/uploader/image9228.jpeg', 'assets/uploader/image9229.jpeg', 1),
(32, 917, 'assets/uploader/image917b.jpeg', 'assets/uploader/image9171.jpeg', 'assets/uploader/image9172.jpeg', 'assets/uploader/image9173.jpeg', 'assets/uploader/image9174.jpeg', 'assets/uploader/image9175.jpeg', 'assets/uploader/image9176.jpeg', 'assets/uploader/image9177.jpeg', 'assets/uploader/image9178.jpeg', 'assets/uploader/image9179.jpeg', 1),
(33, 910898, 'assets/uploader/image910898b.jpeg', 'assets/uploader/image9108981.jpeg', 'assets/uploader/image9108982.jpeg', 'assets/uploader/image9108983.jpeg', 'assets/uploader/image9108984.jpeg', 'assets/uploader/image9108985.jpeg', 'assets/uploader/image9108986.jpeg', 'assets/uploader/image9108987.jpeg', 'assets/uploader/image9108988.jpeg', 'assets/uploader/image9108989.jpeg', 1),
(34, 918, 'assets/uploader/image918b.jpeg', 'assets/uploader/image9181.jpeg', 'assets/uploader/image9182.jpeg', 'assets/uploader/image9183.jpeg', 'assets/uploader/image9184.jpeg', 'assets/uploader/image9185.jpeg', 'assets/uploader/image9186.jpeg', 'assets/uploader/image9187.jpeg', 'assets/uploader/image9188.jpeg', 'assets/uploader/image9189.jpeg', 1),
(35, 919, 'assets/uploader/image919b.jpeg', 'assets/uploader/image9191.jpeg', 'assets/uploader/image9192.jpeg', 'assets/uploader/image9193.jpeg', 'assets/uploader/image9194.jpeg', 'assets/uploader/image9195.jpeg', 'assets/uploader/image9196.jpeg', 'assets/uploader/image9197.jpeg', 'assets/uploader/image9198.jpeg', 'assets/uploader/image9199.jpeg', 1),
(36, 9110, 'assets/uploader/image9110b.jpeg', 'assets/uploader/image91101.jpeg', 'assets/uploader/image91102.jpeg', 'assets/uploader/image91103.jpeg', 'assets/uploader/image91104.jpeg', 'assets/uploader/image91105.jpeg', 'assets/uploader/image91106.jpeg', 'assets/uploader/image91107.jpeg', 'assets/uploader/image91108.jpeg', 'assets/uploader/image91109.jpeg', 1),
(37, 9111, 'assets/uploader/image9111b.jpeg', 'assets/uploader/image91111.jpeg', 'assets/uploader/image91112.jpeg', 'assets/uploader/image91113.jpeg', 'assets/uploader/image91114.jpeg', 'assets/uploader/image91115.jpeg', 'assets/uploader/image91116.jpeg', 'assets/uploader/image91117.jpeg', 'assets/uploader/image91118.jpeg', 'assets/uploader/image91119.jpeg', 1),
(38, 23419, 'assets/uploader/image23419b.jpeg', 'assets/uploader/image234191.jpeg', 'assets/uploader/image234192.jpeg', 'assets/uploader/image234193.jpeg', 'assets/uploader/image234194.jpeg', 'assets/uploader/image234195.jpeg', 'assets/uploader/image234196.jpeg', 'assets/uploader/image234197.jpeg', 'assets/uploader/image234198.jpeg', 'assets/uploader/image234199.jpeg', 1),
(39, 274, 'assets/uploader/image274b.jpeg', 'assets/uploader/image2741.jpeg', 'assets/uploader/image2742.jpeg', 'assets/uploader/image2743.jpeg', 'assets/uploader/image2744.jpeg', 'assets/uploader/image2745.jpeg', 'assets/uploader/image2746.jpeg', 'assets/uploader/image2747.jpeg', 'assets/uploader/image2748.jpeg', 'assets/uploader/image2749.jpeg', 1),
(40, 9112, 'assets/uploader/image9112b.jpeg', 'assets/uploader/image91121.jpeg', 'assets/uploader/image91122.jpeg', 'assets/uploader/image91123.jpeg', 'assets/uploader/image91124.jpeg', 'assets/uploader/image91125.jpeg', 'assets/uploader/image91126.jpeg', 'assets/uploader/image91127.jpeg', 'assets/uploader/image91128.jpeg', 'assets/uploader/image91129.jpeg', 1),
(41, 11, 'assets/uploader/image11b.jpeg', 'assets/uploader/image111.jpeg', 'assets/uploader/image112.jpeg', 'assets/uploader/image113.jpeg', 'assets/uploader/image114.jpeg', 'assets/uploader/image115.jpeg', 'assets/uploader/image116.jpeg', 'assets/uploader/image117.jpeg', 'assets/uploader/image118.jpeg', 'assets/uploader/image119.jpeg', 1),
(42, 23420, 'assets/uploader/image23420b.jpeg', 'assets/uploader/image234201.jpeg', 'assets/uploader/image234202.jpeg', 'assets/uploader/image234203.jpeg', 'assets/uploader/image234204.jpeg', 'assets/uploader/image234205.jpeg', 'assets/uploader/image234206.jpeg', 'assets/uploader/image234207.jpeg', 'assets/uploader/image234208.jpeg', 'assets/uploader/image234209.jpeg', 1),
(43, 910899, 'assets/uploader/image910899b.jpeg', 'assets/uploader/image9108991.jpeg', 'assets/uploader/image9108992.jpeg', 'assets/uploader/image9108993.jpeg', 'assets/uploader/image9108994.jpeg', 'assets/uploader/image9108995.jpeg', 'assets/uploader/image9108996.jpeg', 'assets/uploader/image9108997.jpeg', 'assets/uploader/image9108998.jpeg', 'assets/uploader/image9108999.jpeg', 1),
(44, 9113, 'assets/uploader/image9113b.jpeg', 'assets/uploader/image91131.jpeg', 'assets/uploader/image91132.jpeg', 'assets/uploader/image91133.jpeg', 'assets/uploader/image91134.jpeg', 'assets/uploader/image91135.jpeg', 'assets/uploader/image91136.jpeg', 'assets/uploader/image91137.jpeg', 'assets/uploader/image91138.jpeg', 'assets/uploader/image91139.jpeg', 1),
(45, 9114, 'assets/uploader/image9114b.jpeg', 'assets/uploader/image91141.jpeg', 'assets/uploader/image91142.jpeg', 'assets/uploader/image91143.jpeg', 'assets/uploader/image91144.jpeg', 'assets/uploader/image91145.jpeg', 'assets/uploader/image91146.jpeg', 'assets/uploader/image91147.jpeg', 'assets/uploader/image91148.jpeg', 'assets/uploader/image91149.jpeg', 1),
(46, 9115, 'assets/uploader/image9115b.jpeg', 'assets/uploader/image91151.jpeg', 'assets/uploader/image91152.jpeg', 'assets/uploader/image91153.jpeg', 'assets/uploader/image91154.jpeg', 'assets/uploader/image91155.jpeg', 'assets/uploader/image91156.jpeg', 'assets/uploader/image91157.jpeg', 'assets/uploader/image91158.jpeg', 'assets/uploader/image91159.jpeg', 1),
(47, 9116, 'assets/uploader/image9116b.jpeg', 'assets/uploader/image91161.jpeg', 'assets/uploader/image91162.jpeg', 'assets/uploader/image91163.jpeg', 'assets/uploader/image91164.jpeg', 'assets/uploader/image91165.jpeg', 'assets/uploader/image91166.jpeg', 'assets/uploader/image91167.jpeg', 'assets/uploader/image91168.jpeg', 'assets/uploader/image91169.jpeg', 1),
(48, 275, 'assets/uploader/image275b.jpeg', 'assets/uploader/image2751.jpeg', 'assets/uploader/image2752.jpeg', 'assets/uploader/image2753.jpeg', 'assets/uploader/image2754.jpeg', 'assets/uploader/image2755.jpeg', 'assets/uploader/image2756.jpeg', 'assets/uploader/image2757.jpeg', 'assets/uploader/image2758.jpeg', 'assets/uploader/image2759.jpeg', 1),
(49, 23421, 'assets/uploader/image23421b.jpeg', 'assets/uploader/image234211.jpeg', 'assets/uploader/image234212.jpeg', 'assets/uploader/image234213.jpeg', 'assets/uploader/image234214.jpeg', 'assets/uploader/image234215.jpeg', 'assets/uploader/image234216.jpeg', 'assets/uploader/image234217.jpeg', 'assets/uploader/image234218.jpeg', 'assets/uploader/image234219.jpeg', 1),
(50, 12, 'assets/uploader/image12b.jpeg', 'assets/uploader/image121.jpeg', 'assets/uploader/image122.jpeg', 'assets/uploader/image123.jpeg', 'assets/uploader/image124.jpeg', 'assets/uploader/image125.jpeg', 'assets/uploader/image126.jpeg', 'assets/uploader/image127.jpeg', 'assets/uploader/image128.jpeg', 'assets/uploader/image122.jpeg', 1),
(51, 923, 'assets/uploader/image923b.jpeg', 'assets/uploader/image9231.jpeg', 'assets/uploader/image9232.jpeg', 'assets/uploader/image9233.jpeg', 'assets/uploader/image9234.jpeg', 'assets/uploader/image9235.jpeg', 'assets/uploader/image9236.jpeg', 'assets/uploader/image9237.jpeg', 'assets/uploader/image9238.jpeg', 'assets/uploader/image9232.jpeg', 1),
(52, 924, 'assets/uploader/image924b.jpeg', 'assets/uploader/image9241.jpeg', 'assets/uploader/image9242.jpeg', 'assets/uploader/image9243.jpeg', 'assets/uploader/image9244.jpeg', 'assets/uploader/image9245.jpeg', 'assets/uploader/image9246.jpeg', 'assets/uploader/image9247.jpeg', 'assets/uploader/image9248.jpeg', 'assets/uploader/image9249.jpeg', 1),
(53, 9117, 'assets/uploader/image9117b.jpeg', 'assets/uploader/image91171.jpeg', 'assets/uploader/image91172.jpeg', 'assets/uploader/image91173.jpeg', 'assets/uploader/image91174.jpeg', 'assets/uploader/image91175.jpeg', 'assets/uploader/image91176.jpeg', 'assets/uploader/image91177.jpeg', 'assets/uploader/image91178.jpeg', 'assets/uploader/image91179.jpeg', 1),
(54, 23422, 'assets/uploader/image23422b.jpeg', 'assets/uploader/image234221.jpeg', 'assets/uploader/image234222.jpeg', 'assets/uploader/image234223.jpeg', 'assets/uploader/image234224.jpeg', 'assets/uploader/image234225.jpeg', 'assets/uploader/image234226.jpeg', 'assets/uploader/image234227.jpeg', 'assets/uploader/image234228.jpeg', 'assets/uploader/image23422b.jpeg', 1),
(55, 971, 'assets/uploader/image971b.jpeg', 'assets/uploader/image9711.jpeg', 'assets/uploader/image9712.jpeg', 'assets/uploader/image9713.jpeg', 'assets/uploader/image9714.jpeg', 'assets/uploader/image9715.jpeg', 'assets/uploader/image9716.jpeg', 'assets/uploader/image9717.jpeg', 'assets/uploader/image9718.jpeg', 'assets/uploader/image9719.jpeg', 1),
(56, 9118, 'assets/uploader/image9118b.jpeg', 'assets/uploader/image91181.jpeg', 'assets/uploader/image91182.jpeg', 'assets/uploader/image91183.jpeg', 'assets/uploader/image91184.jpeg', 'assets/uploader/image91185.jpeg', 'assets/uploader/image91186.jpeg', 'assets/uploader/image91187.jpeg', 'assets/uploader/image91188.jpeg', 'assets/uploader/image91189.jpeg', 1),
(57, 9119, 'assets/uploader/image9119b.jpeg', 'assets/uploader/image91191.jpeg', 'assets/uploader/image91192.jpeg', 'assets/uploader/image91193.jpeg', 'assets/uploader/image91194.jpeg', 'assets/uploader/image91195.jpeg', 'assets/uploader/image91196.jpeg', 'assets/uploader/image91197.jpeg', 'assets/uploader/image91198.jpeg', 'assets/uploader/image91192.jpeg', 1),
(58, 9711, 'assets/uploader/image9711b.jpeg', 'assets/uploader/image97111.jpeg', 'assets/uploader/image97112.jpeg', 'assets/uploader/image97113.jpeg', 'assets/uploader/image97114.jpeg', 'assets/uploader/image97115.jpeg', 'assets/uploader/image97116.jpeg', 'assets/uploader/image97117.jpeg', 'assets/uploader/image97118.jpeg', 'assets/uploader/image97119.jpeg', 1),
(59, 9712, 'assets/uploader/image9712b.jpeg', 'assets/uploader/image97121.jpeg', 'assets/uploader/image97122.jpeg', 'assets/uploader/image97123.jpeg', 'assets/uploader/image97124.jpeg', 'assets/uploader/image97125.jpeg', 'assets/uploader/image97126.jpeg', 'assets/uploader/image97127.jpeg', 'assets/uploader/image97128.jpeg', 'assets/uploader/image97129.jpeg', 1),
(60, 9120, 'assets/uploader/image9120b.jpeg', 'assets/uploader/image91201.jpeg', 'assets/uploader/image91202.jpeg', 'assets/uploader/image91203.jpeg', 'assets/uploader/image91204.jpeg', 'assets/uploader/image91205.jpeg', 'assets/uploader/image91206.jpeg', 'assets/uploader/image91207.jpeg', 'assets/uploader/image91208.jpeg', 'assets/uploader/image91209.jpeg', 1),
(61, 9121, 'assets/uploader/image9121b.jpeg', 'assets/uploader/image91211.jpeg', 'assets/uploader/image91212.jpeg', 'assets/uploader/image91213.jpeg', 'assets/uploader/image91214.jpeg', 'assets/uploader/image91215.jpeg', 'assets/uploader/image91216.jpeg', 'assets/uploader/image91217.jpeg', 'assets/uploader/image91218.jpeg', 'assets/uploader/image91219.jpeg', 1),
(62, 9122, 'assets/uploader/image9122b.jpeg', 'assets/uploader/image91221.jpeg', 'assets/uploader/image91222.jpeg', 'assets/uploader/image91223.jpeg', 'assets/uploader/image91224.jpeg', 'assets/uploader/image91225.jpeg', 'assets/uploader/image91226.jpeg', 'assets/uploader/image91227.jpeg', 'assets/uploader/image91228.jpeg', 'assets/uploader/image9122b.jpeg', 1),
(63, 9108100, 'assets/uploader/image9108100b.jpeg', 'assets/uploader/image91081001.jpeg', 'assets/uploader/image91081002.jpeg', 'assets/uploader/image91081006.jpeg', 'assets/uploader/image91081003.jpeg', 'assets/uploader/image91081004.jpeg', 'assets/uploader/image91081005.jpeg', 'assets/uploader/image91081007.jpeg', 'assets/uploader/image91081008.jpeg', 'assets/uploader/image91081009.jpeg', 1),
(64, 9713, 'assets/uploader/image9713b.jpeg', 'assets/uploader/image97131.jpeg', 'assets/uploader/image97132.jpeg', 'assets/uploader/image97133.jpeg', 'assets/uploader/image97134.jpeg', 'assets/uploader/image97135.jpeg', 'assets/uploader/image97136.jpeg', 'assets/uploader/image97137.jpeg', 'assets/uploader/image97138.jpeg', 'assets/uploader/image97139.jpeg', 1),
(65, 9123, 'assets/uploader/image91231.jpeg', 'assets/uploader/image9123b.jpeg', 'assets/uploader/image91232.jpeg', 'assets/uploader/image91233.jpeg', 'assets/uploader/image91234.jpeg', 'assets/uploader/image91235.jpeg', 'assets/uploader/image91236.jpeg', 'assets/uploader/image91237.jpeg', 'assets/uploader/image91238.jpeg', 'assets/uploader/image91239.jpeg', 1),
(66, 9714, 'assets/uploader/image97147.jpeg', 'assets/uploader/image97141.jpeg', 'assets/uploader/image97142.jpeg', 'assets/uploader/image97143.jpeg', 'assets/uploader/image97144.jpeg', 'assets/uploader/image97145.jpeg', 'assets/uploader/image97146.jpeg', 'assets/uploader/image9714b.jpeg', 'assets/uploader/image97148.jpeg', 'assets/uploader/image97149.jpeg', 1),
(67, 925, 'assets/uploader/image925b.jpeg', 'assets/uploader/image9251.jpeg', 'assets/uploader/image9252.jpeg', 'assets/uploader/image9253.jpeg', 'assets/uploader/image925b.jpeg', 'assets/uploader/image9254.jpeg', 'assets/uploader/image9255.jpeg', 'assets/uploader/image9256.jpeg', 'assets/uploader/image9257.jpeg', 'assets/uploader/image9258.jpeg', 1),
(68, 9124, 'assets/uploader/image9124b.jpeg', 'assets/uploader/image91241.jpeg', 'assets/uploader/image91242.jpeg', 'assets/uploader/image91243.jpeg', 'assets/uploader/image91244.jpeg', 'assets/uploader/image91245.jpeg', 'assets/uploader/image91246.jpeg', 'assets/uploader/image91247.jpeg', 'assets/uploader/image91248.jpeg', 'assets/uploader/image91249.jpeg', 1),
(69, 9125, 'assets/uploader/image9125b.jpeg', 'assets/uploader/image91251.jpeg', 'assets/uploader/image91252.jpeg', 'assets/uploader/image91253.jpeg', 'assets/uploader/image91254.jpeg', 'assets/uploader/image91255.jpeg', 'assets/uploader/image91256.jpeg', 'assets/uploader/image91257.jpeg', 'assets/uploader/image91258.jpeg', 'assets/uploader/image91259.jpeg', 1),
(70, 9715, 'assets/uploader/image9715b.jpeg', 'assets/uploader/image97151.jpeg', 'assets/uploader/image97152.jpeg', 'assets/uploader/image97153.jpeg', 'assets/uploader/image97154.jpeg', 'assets/uploader/image97155.jpeg', 'assets/uploader/image97156.jpeg', 'assets/uploader/image97157.jpeg', 'assets/uploader/image97158.jpeg', 'assets/uploader/image97159.jpeg', 1),
(71, 9126, 'assets/uploader/image9126b.jpeg', 'assets/uploader/image91261.jpeg', 'assets/uploader/image91262.jpeg', 'assets/uploader/image91263.jpeg', 'assets/uploader/image91264.jpeg', 'assets/uploader/image91265.jpeg', 'assets/uploader/image91266.jpeg', 'assets/uploader/image91267.jpeg', 'assets/uploader/image91268.jpeg', 'assets/uploader/image91269.jpeg', 1),
(72, 276, 'assets/uploader/image276b.jpeg', 'assets/uploader/image2761.jpeg', 'assets/uploader/image2762.jpeg', 'assets/uploader/image2763.jpeg', 'assets/uploader/image2764.jpeg', 'assets/uploader/image2765.jpeg', 'assets/uploader/image2766.jpeg', 'assets/uploader/image2767.jpeg', 'assets/uploader/image2768.jpeg', 'assets/uploader/image2769.jpeg', 1),
(73, 926, 'assets/uploader/image926b.jpeg', 'assets/uploader/image9261.jpeg', 'assets/uploader/image9262.jpeg', 'assets/uploader/image9263.jpeg', 'assets/uploader/image9264.jpeg', 'assets/uploader/image9265.jpeg', 'assets/uploader/image9266.jpeg', 'assets/uploader/image9267.jpeg', 'assets/uploader/image9268.jpeg', 'assets/uploader/image9269.jpeg', 1),
(74, 9127, 'assets/uploader/image9127b.jpeg', 'assets/uploader/image91271.jpeg', 'assets/uploader/image91272.jpeg', 'assets/uploader/image91273.jpeg', 'assets/uploader/image91274.jpeg', 'assets/uploader/image91275.jpeg', 'assets/uploader/image91276.jpeg', 'assets/uploader/image91277.jpeg', 'assets/uploader/image91278.jpeg', 'assets/uploader/image91279.jpeg', 1),
(75, 9128, 'assets/uploader/image9128b.jpeg', 'assets/uploader/image91281.jpeg', 'assets/uploader/image91282.jpeg', 'assets/uploader/image91283.jpeg', 'assets/uploader/image91284.jpeg', 'assets/uploader/image91285.jpeg', 'assets/uploader/image91286.jpeg', 'assets/uploader/image91287.jpeg', 'assets/uploader/image91288.jpeg', 'assets/uploader/image91289.jpeg', 1),
(76, 23424, 'assets/uploader/image23424b.jpeg', 'assets/uploader/image234241.jpeg', 'assets/uploader/image234242.jpeg', 'assets/uploader/image234243.jpeg', 'assets/uploader/image234244.jpeg', 'assets/uploader/image234245.jpeg', 'assets/uploader/image234246.jpeg', 'assets/uploader/image234247.jpeg', 'assets/uploader/image234248.jpeg', 'assets/uploader/image234249.jpeg', 1),
(77, 9129, 'assets/uploader/image9129b.jpeg', 'assets/uploader/image91291.jpeg', 'assets/uploader/image91292.jpeg', 'assets/uploader/image91293.jpeg', 'assets/uploader/image91294.jpeg', 'assets/uploader/image91295.jpeg', 'assets/uploader/image91296.jpeg', 'assets/uploader/image91297.jpeg', 'assets/uploader/image91298.jpeg', 'assets/uploader/image91299.jpeg', 1),
(78, 9130, 'assets/uploader/image9130b.jpeg', 'assets/uploader/image91301.jpeg', 'assets/uploader/image91302.jpeg', 'assets/uploader/image91303.jpeg', 'assets/uploader/image91304.jpeg', 'assets/uploader/image91305.jpeg', 'assets/uploader/image91306.jpeg', 'assets/uploader/image91307.jpeg', 'assets/uploader/image91308.jpeg', 'assets/uploader/image91309.jpeg', 1),
(79, 9131, 'assets/uploader/image9131b.jpeg', 'assets/uploader/image91311.jpeg', 'assets/uploader/image91312.jpeg', 'assets/uploader/image91313.jpeg', 'assets/uploader/image91314.jpeg', 'assets/uploader/image91315.jpeg', 'assets/uploader/image91316.jpeg', 'assets/uploader/image91317.jpeg', 'assets/uploader/image9131b.jpeg', 'assets/uploader/image91318.jpeg', 1),
(80, 9716, 'assets/uploader/image9716b.jpeg', 'assets/uploader/image97161.jpeg', 'assets/uploader/image97162.jpeg', 'assets/uploader/image97163.jpeg', 'assets/uploader/image97164.jpeg', 'assets/uploader/image97165.jpeg', 'assets/uploader/image97166.jpeg', 'assets/uploader/image97167.jpeg', 'assets/uploader/image97168.jpeg', 'assets/uploader/image97169.jpeg', 1),
(81, 927, 'assets/uploader/image927b.jpeg', 'assets/uploader/image9271.jpeg', 'assets/uploader/image9272.jpeg', 'assets/uploader/image9273.jpeg', 'assets/uploader/image9274.jpeg', 'assets/uploader/image9275.jpeg', 'assets/uploader/image9276.jpeg', 'assets/uploader/image9277.jpeg', 'assets/uploader/image9278.jpeg', 'assets/uploader/image9279.jpeg', 1),
(82, 9132, 'assets/uploader/image9132b.jpeg', 'assets/uploader/image91321.jpeg', 'assets/uploader/image91322.jpeg', 'assets/uploader/image91323.jpeg', 'assets/uploader/image91324.jpeg', 'assets/uploader/image91325.jpeg', 'assets/uploader/image91326.jpeg', 'assets/uploader/image91327.jpeg', 'assets/uploader/image91328.jpeg', 'assets/uploader/image91329.jpeg', 1),
(83, 2111, 'assets/uploader/image211b.jpeg', 'assets/uploader/image2111.jpeg', 'assets/uploader/image2112.jpeg', 'assets/uploader/image2113.jpeg', 'assets/uploader/image2114.jpeg', 'assets/uploader/image2115.jpeg', 'assets/uploader/image2116.jpeg', 'assets/uploader/image2117.jpeg', 'assets/uploader/image2118.jpeg', 'assets/uploader/image2119.jpeg', 1),
(84, 9108101, 'assets/uploader/image9108101b.jpeg', 'assets/uploader/image91081011.jpeg', 'assets/uploader/image91081012.jpeg', 'assets/uploader/image91081013.jpeg', 'assets/uploader/image91081014.jpeg', 'assets/uploader/image91081015.jpeg', 'assets/uploader/image91081016.jpeg', 'assets/uploader/image91081017.jpeg', 'assets/uploader/image91081018.jpeg', 'assets/uploader/image91081019.jpeg', 1),
(85, 9133, 'assets/uploader/image9133b.jpeg', 'assets/uploader/image91331.jpeg', 'assets/uploader/image91332.jpeg', 'assets/uploader/image91333.jpeg', 'assets/uploader/image91334.jpeg', 'assets/uploader/image91335.jpeg', 'assets/uploader/image91336.jpeg', 'assets/uploader/image91337.jpeg', 'assets/uploader/image91338.jpeg', 'assets/uploader/image91339.jpeg', 1),
(86, 9108102, 'assets/uploader/image9108102b.jpeg', 'assets/uploader/image91081021.jpeg', 'assets/uploader/image91081022.jpeg', 'assets/uploader/image91081023.jpeg', 'assets/uploader/image91081024.jpeg', 'assets/uploader/image91081025.jpeg', 'assets/uploader/image91081026.jpeg', 'assets/uploader/image91081027.jpeg', 'assets/uploader/image91081028.jpeg', 'assets/uploader/image91081029.jpeg', 1),
(87, 9134, 'assets/uploader/image9134b.jpeg', 'assets/uploader/image91341.jpeg', 'assets/uploader/image91342.jpeg', 'assets/uploader/image91343.jpeg', 'assets/uploader/image91344.jpeg', 'assets/uploader/image91345.jpeg', 'assets/uploader/image91346.jpeg', 'assets/uploader/image91347.jpeg', 'assets/uploader/image91348.jpeg', 'assets/uploader/image91349.jpeg', 1),
(88, 9135, 'assets/uploader/image9135b.jpeg', 'assets/uploader/image91351.jpeg', 'assets/uploader/image91352.jpeg', 'assets/uploader/image91353.jpeg', 'assets/uploader/image91354.jpeg', 'assets/uploader/image91355.jpeg', 'assets/uploader/image91356.jpeg', 'assets/uploader/image91357.jpeg', 'assets/uploader/image91358.jpeg', 'assets/uploader/image91359.jpeg', 1),
(89, 9136, 'assets/uploader/imagee9136b.jpeg', 'assets/uploader/imagee91361.jpeg', 'assets/uploader/imagee91362.jpeg', 'assets/uploader/imagee91363.jpeg', 'assets/uploader/imagee91364.jpeg', 'assets/uploader/imagee91365.jpeg', 'assets/uploader/imagee91366.jpeg', 'assets/uploader/imagee91367.jpeg', 'assets/uploader/imagee91368.jpeg', 'assets/uploader/imagee91369.jpeg', 1),
(90, 928, 'assets/uploader/image928b.jpeg', 'assets/uploader/image9281.jpeg', 'assets/uploader/image9282.jpeg', 'assets/uploader/image9283.jpeg', 'assets/uploader/image9284.jpeg', 'assets/uploader/image9285.jpeg', 'assets/uploader/image9286.jpeg', 'assets/uploader/image928b.jpeg', 'assets/uploader/image9287.jpeg', 'assets/uploader/image9288.jpeg', 1),
(91, 9137, 'assets/uploader/image9137b.jpg', 'assets/uploader/image91371.jpeg', 'assets/uploader/image91372.jpeg', 'assets/uploader/image91373.jpeg', 'assets/uploader/image91374.jpeg', 'assets/uploader/image91375.jpeg', 'assets/uploader/image91376.jpg', 'assets/uploader/image91377.jpeg', 'assets/uploader/image91378.jpeg', 'assets/uploader/image9137b.jpg', 1),
(92, 2301, 'assets/uploader/image2301b.jpeg', 'assets/uploader/image23011.jpeg', 'assets/uploader/image23012.jpeg', 'assets/uploader/image23013.jpeg', 'assets/uploader/image23014.jpeg', 'assets/uploader/image23015.jpeg', 'assets/uploader/image23016.jpeg', 'assets/uploader/image23017.jpeg', 'assets/uploader/image23018.jpeg', 'assets/uploader/image23019.jpeg', 1),
(93, 9138, 'assets/uploader/image9138b.jpeg', 'assets/uploader/image91382.jpeg', 'assets/uploader/image9138b.jpeg', 'assets/uploader/image91383.jpeg', 'assets/uploader/image91384.jpeg', 'assets/uploader/image91385.jpeg', 'assets/uploader/image91386.jpeg', 'assets/uploader/image91387.jpeg', 'assets/uploader/image91388.jpeg', 'assets/uploader/image91389.jpeg', 1),
(94, 9139, 'assets/uploader/image9139b.jpeg', 'assets/uploader/image91391.jpeg', 'assets/uploader/image91392.jpeg', 'assets/uploader/image91393.jpeg', 'assets/uploader/image91394.jpeg', 'assets/uploader/image91395.jpeg', 'assets/uploader/image91396.jpeg', 'assets/uploader/image91397.jpeg', 'assets/uploader/image91398.jpeg', 'assets/uploader/image91399.jpeg', 1),
(95, 9717, 'assets/uploader/image9717b.jpeg', 'assets/uploader/image97171.jpeg', 'assets/uploader/image97172.jpeg', 'assets/uploader/image97173.jpeg', 'assets/uploader/image97174.jpeg', 'assets/uploader/image97175.jpeg', 'assets/uploader/image97176.jpeg', 'assets/uploader/image97177.jpeg', 'assets/uploader/image97178.jpeg', 'assets/uploader/image97179.jpeg', 1),
(96, 23425, 'assets/uploader/image23425b.jpeg', 'assets/uploader/image234251.jpeg', 'assets/uploader/image234252.jpeg', 'assets/uploader/image234253.jpeg', 'assets/uploader/image234254.jpeg', 'assets/uploader/image234255.jpeg', 'assets/uploader/image234256.jpeg', 'assets/uploader/image234257.jpeg', 'assets/uploader/image234258.jpeg', 'assets/uploader/image234259.jpeg', 1),
(97, 23425, 'assets/uploader/image23425b.jpeg', 'assets/uploader/image234251.jpeg', 'assets/uploader/image234252.jpeg', 'assets/uploader/image234253.jpeg', 'assets/uploader/image234254.jpeg', 'assets/uploader/image234255.jpeg', 'assets/uploader/image234256.jpeg', 'assets/uploader/image234257.jpeg', 'assets/uploader/image234258.jpeg', 'assets/uploader/image234259.jpeg', 1),
(98, 23426, 'assets/uploader/image23426b.jpeg', 'assets/uploader/image234261.jpeg', 'assets/uploader/image234262.jpeg', 'assets/uploader/image234263.jpeg', 'assets/uploader/image234264.jpeg', 'assets/uploader/image234265.jpeg', 'assets/uploader/image234266.jpeg', 'assets/uploader/image234267.jpeg', 'assets/uploader/image234268.jpeg', 'assets/uploader/image234269.jpeg', 1),
(99, 23427, 'assets/uploader/image23427b.jpeg', 'assets/uploader/image234271.jpeg', 'assets/uploader/image234272.jpeg', 'assets/uploader/image234273.jpeg', 'assets/uploader/image234274.jpeg', 'assets/uploader/image234275.jpeg', 'assets/uploader/image234276.jpeg', 'assets/uploader/image234277.jpeg', 'assets/uploader/image234278.jpeg', 'assets/uploader/image234279.jpeg', 1),
(100, 23428, 'assets/uploader/image23428b.jpeg', 'assets/uploader/image234281.jpeg', 'assets/uploader/image234282.jpeg', 'assets/uploader/image234283.jpeg', 'assets/uploader/image234284.jpeg', 'assets/uploader/image23428b.jpeg', 'assets/uploader/image234285.jpeg', 'assets/uploader/image234286.jpeg', 'assets/uploader/image234282.jpeg', 'assets/uploader/image234287.jpeg', 1),
(101, 929, 'assets/uploader/image929b.jpeg', 'assets/uploader/image9291.jpeg', 'assets/uploader/image9292.jpeg', 'assets/uploader/image9293.jpeg', 'assets/uploader/image9294.jpeg', 'assets/uploader/image9295.jpeg', 'assets/uploader/image9296.jpeg', 'assets/uploader/image9297.jpeg', 'assets/uploader/image9298.jpeg', 'assets/uploader/image9299.jpeg', 1),
(102, 9108103, 'assets/uploader/image9108103b.jpeg', 'assets/uploader/image91081031.jpeg', 'assets/uploader/image91081032.jpeg', 'assets/uploader/image91081033.jpeg', 'assets/uploader/image91081034.jpeg', 'assets/uploader/image91081035.jpeg', 'assets/uploader/image91081036.jpeg', 'assets/uploader/image91081037.jpeg', 'assets/uploader/image91081038.jpeg', 'assets/uploader/image91081039.jpeg', 1),
(103, 9140, 'assets/uploader/image9140b.jpeg', 'assets/uploader/image91401.jpeg', 'assets/uploader/image91402.jpeg', 'assets/uploader/image91403.jpeg', 'assets/uploader/image91404.jpeg', 'assets/uploader/image91405.jpeg', 'assets/uploader/image91406.jpeg', 'assets/uploader/image91407.jpeg', 'assets/uploader/image91408.jpeg', 'assets/uploader/image91409.jpeg', 1),
(104, 23429, 'assets/uploader/image23429b.jpeg', 'assets/uploader/image234299.jpeg', 'assets/uploader/image234291.jpeg', 'assets/uploader/image234292.jpeg', 'assets/uploader/image234293.jpeg', 'assets/uploader/image234294.jpeg', 'assets/uploader/image234295.jpeg', 'assets/uploader/image234296.jpeg', 'assets/uploader/image234297.jpeg', 'assets/uploader/image234298.jpeg', 1),
(105, 277, 'assets/uploader/image277b.jpeg', 'assets/uploader/image2771.jpeg', 'assets/uploader/image2772.jpeg', 'assets/uploader/image2773.jpeg', 'assets/uploader/image2774.jpeg', 'assets/uploader/image2775.jpeg', 'assets/uploader/image2776.jpeg', 'assets/uploader/image2777.jpeg', 'assets/uploader/image2778.jpeg', 'assets/uploader/image277b.jpeg', 1),
(106, 9210, 'assets/uploader/image9210b.jpeg', 'assets/uploader/image92101.jpeg', 'assets/uploader/image92102.jpeg', 'assets/uploader/image92103.jpeg', 'assets/uploader/image92104.jpeg', 'assets/uploader/image92105.jpeg', 'assets/uploader/image92106.jpeg', 'assets/uploader/image92107.jpeg', 'assets/uploader/image92108.jpeg', 'assets/uploader/image92109.jpeg', 1),
(107, 9211, 'assets/uploader/image9211b.jpeg', 'assets/uploader/image92111.jpeg', 'assets/uploader/image92112.jpeg', 'assets/uploader/image92113.jpeg', 'assets/uploader/image92114.jpeg', 'assets/uploader/image92115.jpeg', 'assets/uploader/image92116.jpeg', 'assets/uploader/image92117.jpeg', 'assets/uploader/image92118.jpeg', 'assets/uploader/image92119.jpeg', 1),
(108, 9108104, 'assets/uploader/image9108104b.jpeg', 'assets/uploader/image91081041.jpeg', 'assets/uploader/image91081042.jpeg', 'assets/uploader/image91081043.jpeg', 'assets/uploader/image91081044.jpeg', 'assets/uploader/image91081045.jpeg', 'assets/uploader/image91081046.jpeg', 'assets/uploader/image91081047.jpeg', 'assets/uploader/image91081048.jpeg', 'assets/uploader/image91081049.jpeg', 1),
(109, 9108105, 'assets/uploader/image9108105b.jpeg', 'assets/uploader/image91081051.jpeg', 'assets/uploader/image91081052.jpeg', 'assets/uploader/image91081053.jpeg', 'assets/uploader/image91081054.jpeg', 'assets/uploader/image91081055.jpeg', 'assets/uploader/image91081056.jpeg', 'assets/uploader/image91081057.jpeg', 'assets/uploader/image91081058.jpeg', 'assets/uploader/image91081059.jpeg', 1),
(110, 9212, 'assets/uploader/image9212b.jpeg', 'assets/uploader/image92121.jpeg', 'assets/uploader/image92122.jpeg', 'assets/uploader/image92123.jpeg', 'assets/uploader/image92124.jpeg', 'assets/uploader/image92125.jpeg', 'assets/uploader/image92126.jpeg', 'assets/uploader/image92127.jpeg', 'assets/uploader/image92128.jpeg', 'assets/uploader/image92129.jpeg', 1),
(111, 9213, 'assets/uploader/image9213b.jpeg', 'assets/uploader/image92131.jpeg', 'assets/uploader/image92132.jpeg', 'assets/uploader/image92133.jpeg', 'assets/uploader/image92134.jpeg', 'assets/uploader/image92135.jpeg', 'assets/uploader/image92136.jpeg', 'assets/uploader/image92137.jpeg', 'assets/uploader/image92138.jpeg', 'assets/uploader/image92139.jpeg', 1),
(112, 9718, 'assets/uploader/image9718b.jpeg', 'assets/uploader/image97181.jpeg', 'assets/uploader/image97182.jpeg', 'assets/uploader/image97183.jpeg', 'assets/uploader/image97184.jpeg', 'assets/uploader/image97185.jpeg', 'assets/uploader/image97186.jpeg', 'assets/uploader/image97187.jpeg', 'assets/uploader/image97188.jpeg', 'assets/uploader/image97189.jpeg', 1),
(113, 23430, 'assets/uploader/image23430b.jpeg', 'assets/uploader/image234301.jpeg', 'assets/uploader/image234302.jpeg', 'assets/uploader/image234303.jpeg', 'assets/uploader/image234304.jpeg', 'assets/uploader/image234305.jpeg', 'assets/uploader/image234306.jpeg', 'assets/uploader/image234307.jpeg', 'assets/uploader/image23430b.jpeg', 'assets/uploader/image234308.jpeg', 1),
(114, 9141, 'assets/uploader/image9141b.jpeg', 'assets/uploader/image91411.jpeg', 'assets/uploader/image91412.jpeg', 'assets/uploader/image91413.jpeg', 'assets/uploader/image91414.jpeg', 'assets/uploader/image91415.jpeg', 'assets/uploader/image91416.jpeg', 'assets/uploader/image91417.jpeg', 'assets/uploader/image91418.jpeg', 'assets/uploader/image9141b.jpeg', 1),
(115, 9142, 'assets/uploader/image9142b.jpeg', 'assets/uploader/image91421.jpeg', 'assets/uploader/image91422.jpeg', 'assets/uploader/image91423.jpeg', 'assets/uploader/image91424.jpeg', 'assets/uploader/image91425.jpeg', 'assets/uploader/image91426.jpeg', 'assets/uploader/image91427.jpeg', 'assets/uploader/image91428.jpeg', 'assets/uploader/image9142b.jpeg', 1),
(116, 278, 'assets/uploader/image278b.jpeg', 'assets/uploader/image2781.jpeg', 'assets/uploader/image2782.jpeg', 'assets/uploader/image2783.jpeg', 'assets/uploader/image2784.jpeg', 'assets/uploader/image2785.jpeg', 'assets/uploader/image2786.jpeg', 'assets/uploader/image2787.jpeg', 'assets/uploader/image2788.jpeg', 'assets/uploader/image2789.jpeg', 1),
(117, 9143, 'assets/uploader/image9143b.jpeg', 'assets/uploader/image91431.jpeg', 'assets/uploader/image91432.jpeg', 'assets/uploader/image91433.jpeg', 'assets/uploader/image91434.jpeg', 'assets/uploader/image91435.jpeg', 'assets/uploader/image91436.jpeg', 'assets/uploader/image91437.jpeg', 'assets/uploader/image91438.jpeg', 'assets/uploader/image91439.jpeg', 1),
(118, 9719, 'assets/uploader/image9719b.jpeg', 'assets/uploader/image97191.jpeg', 'assets/uploader/image97192.jpeg', 'assets/uploader/image97193.jpeg', 'assets/uploader/image97194.jpeg', 'assets/uploader/image97195.jpeg', 'assets/uploader/image97196.jpeg', 'assets/uploader/image97197.jpeg', 'assets/uploader/image97198.jpeg', 'assets/uploader/image97199.jpeg', 1),
(119, 9720, 'assets/uploader/image9720b.jpeg', 'assets/uploader/image97201.jpeg', 'assets/uploader/image97202.jpeg', 'assets/uploader/image97203.jpeg', 'assets/uploader/image97204.jpeg', 'assets/uploader/image97205.jpeg', 'assets/uploader/image97206.jpeg', 'assets/uploader/image97207.jpeg', 'assets/uploader/image97208.jpeg', 'assets/uploader/image97209.jpeg', 1),
(120, 261, 'assets/uploader/image261b.jpeg', 'assets/uploader/image2611.jpeg', 'assets/uploader/image2612.jpeg', 'assets/uploader/image2613.jpeg', 'assets/uploader/image2614.jpeg', 'assets/uploader/image2615.jpeg', 'assets/uploader/image2616.jpeg', 'assets/uploader/image2617.jpeg', 'assets/uploader/image2618.jpeg', 'assets/uploader/image2619.jpeg', 1),
(121, 9144, 'assets/uploader/image9144b.jpeg', 'assets/uploader/image91441.jpeg', 'assets/uploader/image91442.jpeg', 'assets/uploader/image91443.jpeg', 'assets/uploader/image91444.jpeg', 'assets/uploader/image91445.jpeg', 'assets/uploader/image91446.jpeg', 'assets/uploader/image91447.jpeg', 'assets/uploader/image91448.jpeg', 'assets/uploader/image91449.jpeg', 1),
(122, 279, 'assets/uploader/image279b.jpeg', 'assets/uploader/image2791.jpeg', 'assets/uploader/image2792.jpeg', 'assets/uploader/image2793.jpeg', 'assets/uploader/image2794.jpeg', 'assets/uploader/image2795.jpeg', 'assets/uploader/image2796.jpeg', 'assets/uploader/image2797.jpeg', 'assets/uploader/image2798.jpeg', 'assets/uploader/image2799.jpeg', 1),
(123, 9145, 'assets/uploader/image9145b.jpeg', 'assets/uploader/image91451.jpeg', 'assets/uploader/image91452.jpeg', 'assets/uploader/image9145b.jpeg', 'assets/uploader/image91453.jpeg', 'assets/uploader/image91454.jpeg', 'assets/uploader/image91455.jpeg', 'assets/uploader/image91456.jpeg', 'assets/uploader/image91457.jpeg', 'assets/uploader/image91458.jpeg', 1),
(124, 9146, 'assets/uploader/image9146b.jpeg', 'assets/uploader/image91461.jpeg', 'assets/uploader/image91462.jpeg', 'assets/uploader/image91463.jpeg', 'assets/uploader/image91464.jpeg', 'assets/uploader/image91465.jpeg', 'assets/uploader/image91466.jpeg', 'assets/uploader/image91467.jpeg', 'assets/uploader/image91468.jpeg', 'assets/uploader/image91469.jpeg', 1),
(125, 2710, 'assets/uploader/image2710b.jpeg', 'assets/uploader/image27101.jpeg', 'assets/uploader/image27102.jpeg', 'assets/uploader/image27103.jpeg', 'assets/uploader/image27104.jpeg', 'assets/uploader/image27105.jpeg', 'assets/uploader/image27106.jpeg', 'assets/uploader/image27107.jpeg', 'assets/uploader/image27108.jpeg', 'assets/uploader/image27109.jpeg', 1),
(126, 2541, 'assets/uploader/image254b.jpeg', 'assets/uploader/image2541.jpeg', 'assets/uploader/image2542.jpeg', 'assets/uploader/image2543.jpeg', 'assets/uploader/image2544.jpeg', 'assets/uploader/image2545.jpeg', 'assets/uploader/image2546.jpeg', 'assets/uploader/image2547.jpeg', 'assets/uploader/image2548.jpeg', 'assets/uploader/image2549.jpeg', 1),
(127, 9108106, 'assets/uploader/image9108106b.jpeg', 'assets/uploader/image91081061.jpeg', 'assets/uploader/image91081062.jpeg', 'assets/uploader/image91081063.jpeg', 'assets/uploader/image91081064.jpeg', 'assets/uploader/image91081065.jpeg', 'assets/uploader/image91081066.jpeg', 'assets/uploader/image91081067.jpeg', 'assets/uploader/image91081068.jpeg', 'assets/uploader/image91081069.jpeg', 1),
(128, 2711, 'assets/uploader/image2711b.jpeg', 'assets/uploader/image27111.jpeg', 'assets/uploader/image27112.jpeg', 'assets/uploader/image27113.jpeg', 'assets/uploader/image27114.jpeg', 'assets/uploader/image27115.jpeg', 'assets/uploader/image27116.jpeg', 'assets/uploader/image27117.jpeg', 'assets/uploader/image27118.jpeg', 'assets/uploader/image27119.jpeg', 1),
(129, 23431, 'assets/uploader/image23431b.jpeg', 'assets/uploader/image234311.jpeg', 'assets/uploader/image234312.jpeg', 'assets/uploader/image234313.jpeg', 'assets/uploader/image234314.jpeg', 'assets/uploader/image234315.jpeg', 'assets/uploader/image234316.jpeg', 'assets/uploader/image234317.jpeg', 'assets/uploader/image234318.jpeg', 'assets/uploader/image234319.jpeg', 1),
(130, 9108107, 'assets/uploader/image9108107b.jpeg', 'assets/uploader/image91081071.jpeg', 'assets/uploader/image91081072.jpeg', 'assets/uploader/image91081073.jpeg', 'assets/uploader/image91081074.jpeg', 'assets/uploader/image91081075.jpeg', 'assets/uploader/image91081076.jpeg', 'assets/uploader/image91081077.jpeg', 'assets/uploader/image91081078.jpeg', 'assets/uploader/image91081079.jpeg', 1),
(131, 9147, 'assets/uploader/image9147b.jpeg', 'assets/uploader/image91471.jpeg', 'assets/uploader/image91472.jpeg', 'assets/uploader/image91473.jpeg', 'assets/uploader/image91474.jpeg', 'assets/uploader/image91475.jpeg', 'assets/uploader/image91476.jpeg', 'assets/uploader/image91477.jpeg', 'assets/uploader/image91478.jpeg', 'assets/uploader/image91479.jpeg', 1),
(132, 9149, 'assets/uploader/image9149b.jpeg', 'assets/uploader/image91491.jpeg', 'assets/uploader/image91492.jpeg', 'assets/uploader/image91493.jpeg', 'assets/uploader/image91494.jpeg', 'assets/uploader/image91495.jpeg', 'assets/uploader/image91496.jpeg', 'assets/uploader/image91497.jpeg', 'assets/uploader/image91498.jpeg', 'assets/uploader/image91499.jpeg', 1),
(133, 9148, 'assets/uploader/image9148b.jpeg', 'assets/uploader/image91481.jpeg', 'assets/uploader/image91482.jpeg', 'assets/uploader/image91483.jpeg', 'assets/uploader/image91484.jpeg', 'assets/uploader/image91485.jpeg', 'assets/uploader/image91486.jpeg', 'assets/uploader/image91487.jpeg', 'assets/uploader/image91488.jpeg', 'assets/uploader/image91489.jpeg', 1),
(134, 9150, 'assets/uploader/image9150b.jpeg', 'assets/uploader/image91501.jpeg', 'assets/uploader/image91502.jpeg', 'assets/uploader/image91503.jpeg', 'assets/uploader/image91504.jpeg', 'assets/uploader/image91505.jpeg', 'assets/uploader/image91506.jpeg', 'assets/uploader/image91507.jpeg', 'assets/uploader/image91508.jpeg', 'assets/uploader/image91509.jpeg', 1),
(135, 9108108, 'assets/uploader/image9108108b.jpeg', 'assets/uploader/image91081081.jpeg', 'assets/uploader/image91081082.jpeg', 'assets/uploader/image91081083.jpeg', 'assets/uploader/image91081084.jpeg', 'assets/uploader/image91081085.jpeg', 'assets/uploader/image91081086.jpeg', 'assets/uploader/image91081087.jpeg', 'assets/uploader/image91081088.jpeg', 'assets/uploader/image91081089.jpeg', 1),
(136, 9151, 'assets/uploader/image9151b.jpeg', 'assets/uploader/image91511.jpeg', 'assets/uploader/image91512.jpeg', 'assets/uploader/image91513.jpeg', 'assets/uploader/image91514.jpeg', 'assets/uploader/image91515.jpeg', 'assets/uploader/image91516.jpeg', 'assets/uploader/image91517.jpeg', 'assets/uploader/image91518.jpeg', 'assets/uploader/image91519.jpeg', 1),
(137, 9108109, 'assets/uploader/image9108109b.jpeg', 'assets/uploader/image91081091.jpeg', 'assets/uploader/image91081092.jpeg', 'assets/uploader/image91081093.jpeg', 'assets/uploader/image91081094.jpeg', 'assets/uploader/image91081095.jpeg', 'assets/uploader/image91081096.jpeg', 'assets/uploader/image91081097.jpeg', 'assets/uploader/image91081098.jpeg', 'assets/uploader/image91081099.jpeg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `job_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `job_link` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `job_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`job_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`job_id`, `country_id`, `job_name`, `job_link`, `job_status`) VALUES
(1, 1, 'Middle Age Models (Male/Female)', 'https://www.shine.com/jobs/middle-age-models-malefemale/chikiweb-private-limited/10189056/?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(2, 1, 'Male And Female Models Required', 'https://www.talentrack.in/jobdetail/male-and-female-models-required-for-various-ad-shoot_138704?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(3, 1, 'Urgent Requirement Male/Female For Movie', 'https://wa.me/918977115121', 1),
(4, 2, 'Model Required in pakistan', 'https://www.pakprobiz.com/amp/Models-required-hum-tv-Rawalpindi-123230?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(5, 2, 'Social Media Model', 'https://kyaasstudio.com/ ', 1),
(6, 2, 'Need for Drama', 'https://www.pakprobiz.com/amp/need-actors-actresses-to-be-part-of-a-new-drama-and-film-Islamabad-Capital-132095?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(7, 3, 'Young models recruitment', 'https://www.nigeriada.com/amp/Young-models-recruitment-Lagos-Mainland-1605?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(8, 3, 'High fashion models', 'https://www.amxafrica.com/job/high-fashion-models-lagosnigeria-72-models-needed-urgently/?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(9, 3, 'Luxury Model Search Nigeria', 'https://www.amxafrica.com/job/luxury-model-search-nigeria-lagos-72-model-search/?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(10, 4, 'Models and Production Talent', 'https://jobs.smartrecruiters.com/HugeApeMedia/743999663919398-models-and-production-talent?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(11, 4, 'Fit Model', 'https://denver.jobing.com/pearl-izumi-usa/fit-model?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1),
(12, 4, '2020 Model Search', 'https://jobs.smartrecruiters.com/VeraWear/743999693922615-2020-model-search?utm_campaign=google_jobs_apply&utm_source=google_jobs_apply&utm_medium=organic', 1);

-- --------------------------------------------------------

--
-- Table structure for table `joinmodel`
--

CREATE TABLE IF NOT EXISTS `joinmodel` (
  `jm_id` int(11) NOT NULL AUTO_INCREMENT,
  `refer_id` varchar(200) NOT NULL,
  `jm_name` varchar(200) NOT NULL,
  `jm_number` varchar(200) NOT NULL,
  `jm_email` varchar(200) NOT NULL,
  `jm_date` date NOT NULL,
  `jm_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `joinmodel`
--

INSERT INTO `joinmodel` (`jm_id`, `refer_id`, `jm_name`, `jm_number`, `jm_email`, `jm_date`, `jm_status`) VALUES
(1, 'CUSGDVYUVSGG8911', 'sandeepbhai', '80729172816', 'hjnbfdkjs@gmail.com', '2020-06-24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `models_details`
--

CREATE TABLE IF NOT EXISTS `models_details` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_code` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `agency_id` int(200) NOT NULL,
  `u_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_age` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_gender` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_marital` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_place` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_nationality` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_height` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_weight` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_skintone` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_eyecolor` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_haircolor` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shoesize` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `profession` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `education` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `timingfree` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `outstation` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `outsidecountry` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `seminude` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `nude` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `passport` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `skills` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `hobbies` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `number` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `experience` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `interest` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ethenicwear` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `westernwear` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `swimsuit` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `calendershoot` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `musicalbum` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `indianwear` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shorts` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `allergies` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `fb` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `twitter` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `instagram` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `whatsapplink` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`u_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=137 ;

--
-- Dumping data for table `models_details`
--

INSERT INTO `models_details` (`u_id`, `u_code`, `agency_id`, `u_name`, `u_age`, `u_gender`, `u_marital`, `u_place`, `country`, `u_nationality`, `u_height`, `u_weight`, `u_skintone`, `u_eyecolor`, `u_haircolor`, `shoesize`, `profession`, `education`, `timingfree`, `outstation`, `outsidecountry`, `seminude`, `nude`, `passport`, `skills`, `hobbies`, `language`, `number`, `email`, `address`, `experience`, `interest`, `ethenicwear`, `westernwear`, `swimsuit`, `calendershoot`, `musicalbum`, `indianwear`, `shorts`, `allergies`, `fb`, `twitter`, `instagram`, `whatsapplink`, `status`) VALUES
(1, '2341', 0, 'Agboola Ibukun', '19', 'Female', 'Single', 'Ibadan', '3', 'Nigerian', '5.9 Feet', '50Kg', 'Fair', 'Black', 'Black', 'no', 'Student', 'Not complete yet', 'All time', 'Yes', 'Yes', 'No', 'No', 'Yes', 'Cooking', 'Travelling', 'English,Yoruba', '+2347026160558', 'ibukunagboola7@gmail.com', 'Oba Akinyele street,surelere Ibadan', 'One year in Acting', 'Reading ', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'https://www.facebook.com/funbi.agboola.1', 'http://Www.twitter.com/@ibukun57918964', '', 'https://wa.me/2347026160558', 1),
(2, '271', 0, 'Cynthia Buthelezi', '23 ', 'female ', 'single ', 'kwazulu natal', '6', 'South Africa', '3.2 feet', '48 Kg', 'Fair', 'Black', 'Black', '4', 'Actor', '11th ', 'Any time', 'Yes', 'Yes', 'No', 'No', 'Yes', 'Strong communication', 'Dance', 'English and isizulu', '+27790133822', '9701170912087', 'Stanger dessaai flat 20', 'No experience', 'acting ', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', '', 'https://wa.me/27790133822', 1),
(3, '2342', 0, 'Rosemary', '18', 'Female', 'Single', 'Yola', '3', 'Nigeria', '5.6 Feet', '53 Kg', 'fair ', 'Black', 'Black', '39', 'Model', 'B.sc', 'Any time', 'No', 'No', 'No', 'No', 'Yes', 'Baking', 'photograph ', 'English and Hausa', '+2347030833904', 'rosemaryalesa5@gmail.com', 'Jimeta Yola', 'Fresher', 'Travelling', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', '', 'https://wa.me/2347030833904', 1),
(4, '2343', 0, 'Samuel Lizzy', '22', 'female', 'single', 'Afo', '3', 'Nigeria', '6.3 feet', '56 Kg', 'fair', 'black', 'black', '9', 'modeling', 'MLS', 'Any Time', 'yes', 'yes', 'No', 'No', 'Yes', 'strong communicate skills,adopt to all situations', 'music,dancing, reading,singing,traveling and fashion ', 'English, yoruba', '2347035015600', 'samuelodunayo36@gmail.com', '11 Aderonmu street owo, ondo state', '1year in modeling', 'acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'No', 'no', 'http://Www.twitter.com/@ibukun57918964', '', 'https://wa.me/2347035015600', 1),
(5, '2344', 0, 'Ajayi boluwatife', '20', 'female', 'single', 'Lagos', '3', 'Nigerian', '5.8 feet', '50 Kg', 'chocolate', 'brown', 'brown', '39', 'model', 'ECE', 'Any time', 'Yes ', 'Yes', 'Yes', 'No', 'No', 'along with practically everyone,good to work with', 'singing, dancing, visiting places,\r\nWriting articles', 'English, yoruba', '2347014230940', 'boluwatifeajayi91@gmail.com', 'Lagos, Nigerian', '6 month', 'acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '', 'https://wa.me/2347014230940', 1),
(6, '2345', 0, 'Osigbemhe Glory', '20', 'female', 'single', 'Edo state', '3', 'Nigeria ', '5.7 feet', '60 Kg', 'fair', 'black', 'black', '40', 'dance', 'anatomy', 'Any time', 'yes', 'yes', 'No', 'No', 'yes', 'strong communication skills,adopt to all situations', 'traveling, listening to music,dancing,etc ', 'English,Esan', '2348107682314', 'no', 'akoamen strt,opp area command,usugbenu road,irrua,Esan central,Edo state', 'Fresher', 'Travelling', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'No', 'https://www.facebook.com/100045058547365/posts/141455197366431/?d=n&substory_index=0', 'https://twitter.com/g_osigbemhe/status/1253450563494313985?s=12', '', 'https://wa.me/2348107682314', 1),
(7, '2346', 0, 'Peace Edem ', '25', 'Female ', 'Single ', 'Lagos ', '3', 'Nigeria ', '5.6 feet', '53 Kg', 'Caramel ', 'black', 'black', '40', 'Caterer ', 'B.sc', 'Any time', 'yes', 'yes', 'No', 'No', 'yes', 'strong communicatie skills,adopt to all situations', 'Singing, jokes, music, eating, net surfing, reading, trying new things', 'English, Yoruba, Efik', '234 909 099 9556', 'edempeace4@gmail.com', 'plot 10 ojuore Estate, Lagos ', 'One year in catrering', 'acting', 'Yes', 'Yes', 'yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'https://www.facebook.com/profile.php?id=100023473313865', 'no', '', 'https://wa.me/2349090999556', 1),
(8, '2347', 0, 'Damilola', '18', 'female', 'single', 'Ibadan', '3', 'Nigerian', '5.8 feet', '60', 'Dark', 'Black', 'Black', '40', 'artist', 'OND', 'Any time', 'yes', 'yes', 'No', 'No', 'No', 'strong communication skills', 'creating artistic things, music, trying new things, cooking', 'English and Yoruba', '2349018484596', 'damilolaawodiya2@gmail.com', 'NO 8 adagbada, Akodu, apete, Ibadan, oyo state', 'two years in an art studio and a year experience in modelling ', 'acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '', 'https://wa.me/2348103440142', 1),
(9, '911', 0, 'Heren', '35', 'male', 'single', 'Gujarat and Mumbai', '1', 'Indian', '6 feet', '75 Kg', 'fair', 'brown', 'black', '10', 'Actor and model', 'Diploma in fashion design', 'Any time', 'yes', 'yes', 'no', 'no', 'Applied', 'acting, dancing, painting,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, Gujarati', '+9172858 02785', 'herenpastagia@gmail.com', '38, laljinagar soc. Adajan, Surat', '2 years in acting', 'acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'No', 'no', 'no', '', 'https://wa.me/917285802785', 1),
(10, '912', 0, 'Abhay ', '17', 'male', 'single', 'delhi', '1', 'indian', '5.4 feet', '45 Kg', 'bright', 'brown', 'black', '7', 'modling', '10 cleared these year on 12', 'Any time', 'yes', 'yes', 'No', 'No', 'No', 'strong communic skills,adopt to allation situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading,acting playing cricket', 'English, Hindi', '7982144118', 'luckyyadas12@gmail.com', '215 Shiv Ram park', 'fresher ', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', '', 'https://wa.me/917982144118', 1),
(11, '913', 0, 'Rishi', '21', 'male', 'single', 'nagpur ', '1', 'Indian', '5.12 feet', '65', 'brown', 'Black', 'Black', '9', 'student ', 'b.sc', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, marathi ', '917066776046', 'rushikeshbhatkar20@gmail.com', 'gandhi chowk,arvi', 'Fresher', 'acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'No', 'No', 'no', '', 'https://wa.me/917066776046', 1),
(23, '23416', 0, 'Emmanuel ', '20', 'male', 'single', 'Lagos', '3', 'Nigeria', '5.3 Feet', '73 Kg', 'chocolate ', 'black', 'black', '45', 'dancer', 'No', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'dancing', 'dancing,travelling, meeting new friends', 'English, cross river', '2347017086612', 'emmanbreezy09@gmail.com ', '18 obafalabi street ojodu begger lagos', '5yrs in dancing', 'acting,model', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'No', 'no', 'no', 'no', 'https://wa.me/2347017086612', 1),
(12, '2348', 0, 'irivri favour mamuzo', '19', 'female', 'single', 'Delta State ,warri', '3', 'Nigerian', '5.3 feet', '53 Kg', 'chocolate', 'black', 'black', '10', 'singer', 'ond', 'Any time', 'yes', 'yes', 'No', 'No', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English', '2349016447340', 'irivrimamuzo@gmail.com', 'no', 'one year in singing', 'acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'No', 'No', 'No', '', 'https://wa.me/2349016447340', 1),
(13, '2349', 0, 'Nayah', '17', 'female', 'single', 'Nigeria', '3', 'Nigerian', '4.8 feet', '50 Kg', 'fair', 'Black', 'Black', '40', 'modella', 'bsc', 'Any time', 'yes', 'yes', 'No', 'No', 'yes', 'strong communication skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , cooking', 'English, igbo', '2348097110267', 'aguigbofavour@gmail.com', 'Nigeria, Abuja gwagwalada', 'one year in acting', 'yes', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'Dust', 'No ', 'No', '', 'https://wa.me/2348097110267', 1),
(14, '23410', 0, 'Austin flourish ibukunoluwa', '1', 'female', 'single', 'Ibadan', '3', 'Nigeria', '3.1 feet', '20 Kg', 'light', 'black', 'brown', '2', 'model', 'creche', 'yes', 'Any', 'yes', 'yes', 'no', 'no', 'strong communication', 'dancing singing', 'Yoruba English', '2348103440142', 'aderinboyeolayinka06@gmail.com', 'no', 'no', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', '', 'https://wa.me/2348103440142', 1),
(15, '23411', 0, 'Maduegbnam Sochima Blessing ', '22', 'female', 'single', 'Anambra state ', '3', 'Nigerian', '5.4 feet', '57 Kg', 'fair', 'black', 'black', '9', 'student ', 'library and Information Science ', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'Caring, teamwork, active listening, mindfulness and honesty', 'traveling,music ,dancing,trying and learning new things ,  reading', 'English, Igbo', '2349068985457 ', 'Sochimamaduegbunam@gmail.com', 'St Stephen''s hostel, ifite Awka road, Anambra state ', 'Fresher', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '', 'https://wa.me/2349068985457', 1),
(16, '23412', 0, 'sharex', '17', 'female', 'single', 'Nigeria', '3', 'Nigeria', '5.4 feet', '50 Kg', 'brown', 'black', 'black', '40', 'modella', 'bsc', 'Any time', 'yes', 'yes', 'no', 'no', 'Yes', 'strong communication skills,adopt to all situations', 'traveling, partying,music ,dancing,trying new things ,singing', 'English', '2348118953872', 'sharoniwe3@gmail.com', 'Nigeria, Abuja gwagwalada', 'one year in acting and singing', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '', 'https://wa.me/2348118953872', 1),
(17, '914', 0, 'Jagdeep Singh', '25', 'Male', 'single', 'UP Bijnor', '1', 'Indian', '6 feet', '103 Kg', 'fair', 'black', 'black', '10', 'Acting ', 'BA in English', 'Any time', 'Yes', 'Yes', 'No', 'No', 'Yes', 'strong communicatie skills,adopt to all situations\r\n', 'traveling, Acting, Mimicry, Reading, singing', 'Punjabi, English, Hindi', '+919990153133', ' Mrgill5500@gmail.com', 'Bijnor Uttar pardesh\r\n', '5 month theater in Dubai, shoot audition video, have Cintta artist card.', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'https://www.facebook.com/profile.php?id=100015739831570', 'no', 'https://www.instagram.com/invites/contact/?i=o5gseknjb7y3&utm_content=479gjsh', 'https://wa.me/919990153133', 1),
(18, '23413', 0, 'Vera', '17', 'female', 'single', 'Nigeria', '3', 'Nigeria', '4.5 feet  \r\n', '45 Kg', 'Dark', 'black', 'black', '38', 'modella', 'bsc', 'Any time', 'yes', 'yes', 'No', 'No', 'yes', 'adapt to all situations, strong communication skills', 'singing, rapping,    listening to music', 'English, Hausa', '2347010773145', 'vero.libini@gmail.com', 'Nigeria, abuja', 'instrumental', 'acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'No', 'no', 'no', '', 'https://wa.me/2347010773145', 1),
(19, '23414', 0, 'Olagboye Lydia Praise', '19', 'Female', 'Single', 'Ibadan', '3', 'Nigeria', '5.3 feet', '58 Kg', 'light', 'black', 'black', '38', 'model', 'Higher institution', 'Any time', 'yes', 'yes', 'No', 'No', 'NO', 'Good communication', 'Dancing', 'Yoruba English', '08069042910 or08132855048', 'No', 'old Ife road new gbagi', '1 month', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', '', 'https://wa.me/2348103440142', 1),
(20, '915', 0, 'Mohita', '26', 'female', 'single', 'Dehli ', '1', 'Indian', '5.2 feet', '45 Kg', 'whiteshbrown', 'black', 'black', '7', 'Tellecaller', 'B.tech', 'Any time', 'yes', 'yes', 'No', 'No', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi', '8126006949', 'mohitaverma11@gmail.com', 'Delhi', 'Fresher', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'https://twitter.com/shizuka976145?s=09', 'https://www.instagram.com/invites/contact/?i=a4c2zrksb9eq&utm_content=3btrl0r', 'mailto:mohitaverma11@gmail.com?Subject=Hello%20again', 1),
(21, '272', 0, 'Mixo Britney Chauke', '17', 'Female', 'Single', 'Johannesburg, Tembisa', '6', 'Black', '3.4 feet', '15 Kg', 'Light', 'Black', 'Black', '4', 'Actress ', 'Still studying (Grade 11)', 'Any time', 'Yes', 'Yes', 'No', 'No', 'No', 'Good communication skills,Team work,time management', 'Highly activated and participates in Dramas and sports', 'Xitsonga, English', '27739592786', '0308291257084', '473/393 Difateng, Tembisa 1632', 'Acting(2 years) ', 'Acting', 'No', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', '', 'https://wa.me/27739592786', 1),
(22, '23415', 0, 'Norah Emilia ', '17 ', 'female ', 'single ', 'Lagos ', '3', 'Nigeria ', '6 feet ', '54 ', 'fair ', 'brown ', 'golden ', '39 ', 'chef ', 'just finished secondary school ', 'Any time', 'Yes', 'Yes', 'No', 'No', 'No', 'strong \r\nCommunicate skill,adopt to all situations', 'travelling ,music ,dancing ,cooking ,trying new things ,netsurfing and reading ', 'English ', '2348064728275', 'No', 'No', 'practical in cooking ', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', '', 'https://wa.me/2348064728275', 1),
(24, '916', 0, 'Rahul Sharma', '27', 'male', 'single', 'Bhilwara Rajasthan', '1', 'India', '6.3 Feet', '83 Kg', 'fair', 'brown', 'brown', '10', 'Model', 'MCA', 'Any time', 'yes', 'yes', 'yes', 'No', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, punjabi', '9057255083', 'rahulsh8307@gmail.com', '06 satliyas potlan, district Bhilwara Rajasthan', '6 months', 'acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'No', 'https://www.facebook.com/rahulkailashsharma/', 'https://twitter.com/rahulsh8307_k', 'https://www.instagram.com/rahulkailash.sharma/', 'https://wa.me/918875287194', 1),
(27, '23418', 0, 'obisesan oluwaseun', '20', 'female', 'single', 'Ibadan', '3', 'Nigeria', 'No', 'no', 'fair', 'black', 'black', '37', 'Student', 'ssce', 'Any time', 'yes', 'no', 'no', 'no', 'yes', 'strong communication, adapt to all situation', 'music, dancing, reading,cooking, learning', 'English, Yoruba', '09022490856,08075999251', 'luwaseunobisesan98@gmail .com', 'no 6,olupoyi street, olakunle,apata,Ibadan', 'Fresher', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/2348075999251', 1),
(28, '910897', 0, 'Deepali Gaur', '20', 'female', 'single', 'New Delhi', '1', 'Indian', '5.4 Feet', '52', 'fair', 'brown', 'brown', '5', 'Model', 'b.com', 'Any time', 'Yes', 'Yes', 'No', 'No', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, punjabi', '8860393888', 'deepaligaur4242@gmail.com ', '3/102,103 khichripur delhi - 91', '6 Months', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'mailto:deepaligaur4242@gmail.com?Subject=Hello%20again', 1),
(26, '23417', 0, 'Bella Louis', '20', 'female', 'single', 'jos', '3', 'Nigeria', '5.8 feet', '48', 'caramel ', 'brown ', 'brown ', '40', 'modeling', 'admin/planning', 'Any time', 'yes ', 'yes ', 'No', 'No', 'yes ', 'strong communication', 'dancing and reading', 'English', '+2347087964615', 'no', 'Nigeria', 'I year training as a makeup artist and a hairstylist', 'acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'https://wa.me/2347087964615', 1),
(29, '273', 0, 'Lerato', '20', 'female', 'single', 'Sebokeng ', '6', 'South African ', '6.7 Feet', '62', 'fair', 'black', 'black', '6', 'singer', 'still studying ', 'Any time', 'yes', 'yes', 'No', 'No', 'No', 'adopt to all situations', 'Reading & Dancing ', 'English, Sotho, Zulu, Xhosa', '234789197132 ', 'no', '2652 Boitumelo', 'Fresher', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/27627588099', 1),
(30, '922', 0, 'Ahmad Shahzad ', '24', 'male', 'single', 'Pakistan ', '2', 'Pakistani', '6.3 Feet', '85', 'fair', 'brown', 'brown', '9', 'model', 'BA', 'Any time', 'yes', 'yes', 'yes', 'No', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, punjabi,chinese, \r\nHindko', '0092300-5551524', 'mulphico34@gmail.com', 'Pakistan Peshawar ', '5 year in modeling ', 'Acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'No', 'no', 'no', 'no', 'https://wa.me/923005551524', 1),
(32, '917', 0, 'Siddharth Mehra', '25', 'Male', 'Single', 'Mumbai', '1', 'Indian', '6.1 Feet', '80 Kg', 'Dusky', 'black', 'black', '10', 'Line producer, Actor and Model', 'Undergraduate', 'Any time', 'Yes', 'Yes', 'Yes', 'No', 'Applied', 'strong communication skills,adopt to all situations ', 'Social helper, Gyming, Trecking, Training Dogs,traveling, football, Cricket, parting,music ,dancing,trying new things , net surfing', 'English, Hindi, punjabi,Marathi,', '8080099969', 'mehra.siddharth95@hotmail.com', 'Bungalow no 001, Mateshwari, opposite Krishna Vandana CHS, Usarli Road, Vichumbe Gao, New Panvel,410206', 'Worked in many daily soaps and ad films as an artist', 'Acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/918080099969', 1),
(33, '910898', 0, 'seema chaudhary', '21', 'female', 'single', 'Arunachal pradesh', '1', 'Indian', '5.7 Feet', '50 Kg', 'light brown', 'Dark brown', 'black', '7', 'student', 'B.A political science', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'Tailoring, hair styles,adopt to all situations', 'traveling, cooking,gardening,music,trying new things ,reading,write poetry', 'English, Hindi, bhojpuri little, and bengali', '8974757461', 'skcseema7721@gmail.com', 'arunachal pradesh, east siang district ( pasighat) ', 'entrepreneur 6 month, and editing picture', 'Acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'mailto:skcseema7721@gmail.com?Subject=Hello%20again', 1),
(34, '918', 0, 'Vinay Mehta ', '23', 'male', 'single', 'Banswara', '1', 'Indian', '5.5 Feet', '62 Kg', 'fair', 'black', 'black', '7', 'Student', 'B.tech', 'Any time', 'Yes', 'No', 'No', 'No', 'No', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading,cooking,gardening', 'English, Hindi, Gujarati ,Rajasthani', '7568264952', ':Vmehta801@gmail.com', 'ashirwaad school subhash nagar banswara Rajasthan 327001', '2 years in anchoring', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'No', 'https://wa.me/919001092208', 1),
(35, '919', 0, 'Rajat Sharma', '27', 'male', 'single', 'Sadulpur ', '1', 'Indian', '5.8 Feet', '65 Kg', 'fair', 'black', 'black', '9', 'Actor/Model/Singer', 'B.Tech', 'Any time', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,Acting,trying new things , net surfing, reading', 'English, Hindi, Haryanvi', '9461605004', 'rajatbkbiet@gmail.com', 'Ward No 24, Near kandoi bhawan,  Rajgarh,  Dist. - Churu 331023', 'I have done more than 5 modeling peagents.. Worked in acting with news nation channel for khalnayak..currently i have selected for voice over artist by FTC Talent', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/919461605004', 1),
(36, '9110', 0, 'prajwal dubey', '20', 'Male ', 'single', 'Maharashtra ', '1', 'Indian', '5.11 Feet', '55 Kg', 'Medium', 'black ', 'black ', '9', 'acting & dancing ', '12th board exam given', 'Any time', 'Yes', 'Yes', 'No', 'No', 'No', 'Dancing', 'traveling ', 'Hindi, Marathi.', '9595753718 /7558331804', 'prajwaldubey1155@gmail.com ', 'hind nagar wardha Maharashtra', 'Fresher', 'Acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'No', 'no', 'no', 'no', 'https://wa.me/919595753718', 1),
(37, '9111', 0, 'Yogesh', '28', 'Male', 'single', 'Mumbai', '1', 'Indian', '6 Feet', '76 Kg', 'Wheatish ', 'Dark brown', 'Black', '9', 'Actor', 'Bachelor of Engineering ', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'traveling, music,  sports, reading, sketching, writing, singing', 'English, Hindi, Urdu, Bhopali, Bundelkhandi', '8962472900', 'ahirwaryogesh7@gmail.com ', 'yari road, versova andheri west, Mumbai', '3 years in theatre', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/918962472900', 1),
(38, '23419', 0, 'Afolabi oluwatosin', '15 years', 'female', 'single', 'ibadan', '3', 'Nigerian', '6 Feet', '32 Kg', 'dark', 'black', 'black', '39', 'Student', 'secondary ', 'Any', 'yes', 'yes', 'no', 'no', 'no', 'communicating skill', 'singing, dancing and taking pics', 'English', '2347013110334', 'Oluwatosinafolabi72 @gmail.com', 'Abese oluyole extension Ibadan', 'Fresher', 'Acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/2347013110334', 1),
(39, '274', 0, 'winnie', '18', 'female', 'single', 'Jo burg', '6', 'South Africa', '5.2 Feet', '52', 'fair', 'Black', 'Black', '6', 'actress', 'O level', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'fast learner ,adopt to all situations , strong communicate skills', 'watching series,acting, getting  to know new people, learning new things', 'English, shona ,xhosa', '27736922783', 'no', 'no', 'Fresher', 'Acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'No', 'no', 'no', 'no', 'https://wa.me/27736922783', 1),
(40, '9112', 0, 'paritosh kunar  ', '30', 'Male               ', 'single                 ', 'Patna                                   ', '1', 'Indian', '5.6 Feet', '50 Kg', 'fair                              ', 'black                         ', 'black                         ', '9', 'actor                        ', 'graduate                   ', 'Any time', 'Yes', 'Yes', 'no', 'no', 'no', 'strong communicate skills', 'parting, music, reading, net surfing, travelling', 'Hindi & English ', '9386901600/7991164262', 'pkparitosh999@gmail.com', 'Chowk shikarpur jitu lal lane nalapar patna city dist patna', 'Fresher', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/919386901600', 1),
(41, '11', 0, 'Gatita', '28', 'female', 'Happily married', 'Florida', '4', 'Hispanic', '5.4 Feet', '145 Pound', 'Fair', 'Dark brown', 'Black', '10', 'Tarot Reader', 'High School', 'Any time', 'Yes', 'Yes', 'No', 'No', 'No', 'Bubbly personality,Good with communicating.Fun,adventurous.Bilingual.', 'Love to learn and read Wicca,Study tarot and Oracle cards, horror and comedy movies,park,long walks in cemeteries,Spells,rituals,Shopping,Metal,Goth,Rap  music,Makeup,nails,and hair', 'English and Spanish', '(386)481-3853,', 'GothicAngels13@hotmail.com', 'no', 'Fresher', 'Acting and Modeling', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'https://m.facebook.com/profile.php?id=100001591129905', 'no', 'no', 'mailto::GothicAngels13@hotmail.com?Subject=Hello%20again', 1),
(42, '23420', 0, 'Jennifer', '20', 'female', 'single', 'owerri', '3', 'Nigeria', '5.2 Feet', '50 Kg', 'fair', 'Black', 'Brown', '39', 'student', 'B.Ed', 'Any Time', 'yes', 'no', 'no', 'no', 'yes', 'adopt to all situations', 'music,acting,reading,dancing', 'English,Nigerian', '+234 8100108949', 'Ihekwuabajennifer8@gmail.com', 'IMO Nigeria', 'pageant contest', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/2348100108949', 1),
(43, '910899', 0, 'Sanjana', '22', 'female', 'single', 'Delhi', '1', 'Indian', '5.1 Feet', '56 Kg', 'fair', 'black', 'black', '5', 'Guest relation assistant ', 'b.sc in hospitality and hotel administration degree ', 'Day Time(INDIA)', 'Yes', 'no', 'no', 'no', 'Yes', 'strong, independent, flexible, cheerful, passionate and ambitious girl with Amazing intellectual skills ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, punjabi', '8178054403', 'sanj.bhargava17@gmail.com', 'no', 'Work in a real estate industry ', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'mailto:sanj.bhargava17@gmail.com?Subject=Hello%20again', 1),
(44, '9113', 0, 'Sahil Arora', '22', 'Male', 'single ', 'Delhi ', '1', 'Indian', '5.8 Feet', '65kg', 'Fair', 'Black', 'Brown', '8', 'Makeup artist', 'B.com', 'Early morning,late night, weekend', 'yes', 'yes', 'No', 'No', 'yes', 'good communicatie skills,adopt to all situations ', 'Traveling, Cooking, Art parting ,dancing,trying new things', 'English, Hindi', '7836911539', 'sahil82aroar@gmail.com', 'Delhi', '3 year in Makeup artist', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/917836911539', 1),
(45, '9114', 0, 'T.Raghavendra Nath', '40', 'Male', 'Married ', 'Kurnool', '1', 'Indian', '5.5 Feet', '64 kg', 'Fair', 'Black', 'Black', '7', 'Film Direction', 'High Secondadry', 'Any time', 'Yes', 'Yes', 'No', 'No', 'No', 'Direction,acting& strong communicate skills adopt to all situations', 'Listen to music & workout with scripts Languages ', 'Telugu&little bit Kannada', '08019533696', 'raghavendranat.teerpula@gmail.com', '51/965A,SitaramaNagar,Kurnool,Andhra Pradesh,India', 'I worked as an assistant director in Tollywood 1999 to 2003', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/918019533696', 1),
(46, '9115', 0, 'Raj eluri', '27', 'male', 'single', ' AP( Ongole)', '1', 'Indian', '6 Feet', '77 Kg', 'fair', 'black', 'black', '10', 'Sales financer', 'degree', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'traveling, music ,trying new things , reading', 'English, telugu', '9490645262', 'rajeluri89777@gmail.com', 'no', '1 year in anchoring field', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/919490645262', 1),
(47, '9116', 0, 'Rohit jangid', '19', 'Male', 'Single', 'Jaipur', '1', 'Indian', '5.11 Feet', '56 Kg', 'fair', 'black', 'black', '8', 'Dance', '12th ', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling  parting,music ,dancing,trying new things , net surfing', 'English, Hindi', '9929107807', 'rohit7807sharma@gmail.com', 'om colony jai singh pura khor jaipur Rajasthan', '4 year in dancing', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/919929107807', 1),
(48, '275', 0, 'samkelisiwe', '17', 'female', 'Relationship', 'Durban', '6', 'black', '5.3 Feet', '60 Kg', 'light', 'black', 'black', '6', 'Student', 'grade 10', 'week days', 'yes', 'no', 'no', 'no', 'no', 'braids  n styling', 'music, singing, reading, watching movies n taking pic', 'Zulu and English', '+2792454469', 'no', '199056 iNanda 4310', 'Fresher', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'tel:2792454469', 1),
(49, '23421', 0, 'Udekwe Favour', '16', 'female', 'single', 'Lagos ', '3', 'Nigerian', '5.3 Feet', '46', 'light chocolate', 'brown', 'brown', '39', 'Student & Fashion designer', 'O-level', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'Design clothes, dance, rap,act', 'Dancing, video gaming', 'English, igbo', '8154147345', 'chinecfavour@gmail.com', ' Iju shaga. Lagos State', 'Fresher', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/2348154147345', 1),
(50, '12', 0, 'Becca ', '21', 'female', 'complicated relationship ', 'America', '4', 'American', '5.5 Feet', '113lbs ', 'white ', 'dark green ', 'blonde ', '5', 'Student', 'college ', 'Any', 'yes', 'yes', 'yes', 'yes', 'yes', ',music ,dancing, parties, shopping, exercise, yoga', 'English', 'acting', '1 (312) 445-0781', 'Beckysmith28@aol.com', 'no', 'Fresher', 'Acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'mailto:Beckysmith28@aol.com?Subject=Hello%20again', 1),
(51, '923', 0, 'Touseef mughal', '21', 'male', 'single', 'lahore', '2', 'Pakistan', '5.7 Feet', '65 Kg', 'fair', 'black', 'black', '9', 'Model', 'I.com', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communication skills', 'Reading', 'eng urdu punjabi', '03217558221', ' mughaltouseef9@gmail.com', 'house no 518 block no 4 sector A2 town ship lahore', 'one half year struggling in field', 'acting ', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/923217558221', 1),
(52, '924', 0, 'ROCKEY\r\n', '32\r\n', 'Male\r\n', 'Married\r\n', 'Peshawar', '2', 'pakistani\r\n', '5.8 Feet', '80 Kg', 'fair\r\n', 'brown\r\n', 'black\r\n', '9\r\n', 'sales\r\n', 'MBA\r\n', 'Any time', 'yes\r\n', 'yes\r\n', 'no', 'no', 'yes\r\n', 'strong communicatie skills,adopt to all situations ', 'Body building, Modeling, net surfing, reading', 'English, urdu, Pashtu', '+92-331-9179299', 'jrenterprises701@gmail.com', 'Samdo Garhi Bashir Adab Pajjagi Road Peshawar Pakistan.', 'Fresher', 'Reading,Modelling', 'yes\r\n', 'yes\r\n', 'no', 'yes\r\n', 'yes\r\n', 'yes\r\n', 'yes\r\n', 'no', 'no', 'no', 'no', 'https://wa.me/923319179299', 1),
(53, '9117', 0, 'Sreeram', '28', 'Male', 'single', 'Coimbatore ', '1', 'Indian', '6.2 Feet', '82 Kg', 'fair', 'black', 'black', '10', 'actor', 'M.Tech', 'Any Time', 'yes', 'yes', 'yes', 'no', 'Yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, tamil, telegu', '9442168096', 'sreeram076@gmail.com', 'Coimbatore ', 'one year in Short Film ', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/919442168096', 1),
(54, '23422', 0, 'Daniel favour Samuel ', '20 ', 'male', 'single ', 'Nigeria ', '3', 'Nigeria ', '6 Feet', '36 Kg', 'light', 'black', 'black', '45', 'sylist ', 'Not disclosed', 'Any time', 'Yes', 'Yes', 'no', 'no', 'no', 'adopt to all situations ', 'singing, reading novel, thinking big', 'English ', '2347064378158 ', 'no', '24 okaka street sango area ilorin kwara state Nigeria', 'Fresher', 'acting ', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/2347064378158', 1),
(55, '971', 0, 'Nisha Gautam', '25', 'female', 'single', 'Nepal ', '8', 'Nepalese', '5.1 Feet', '48 Kg', 'fair', 'brown', 'brown', '37', 'ordinater,choreographer', 'bsw 2nd running ', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things', 'English, Nepali,Hindi', '+9779821117229', 'ggrifin81@gmail.com', 'Nepal', '1 Year(Ramp walk)', 'Ramp work,Acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'mailto:ggrifin81@gmail.com?Subject=Hello%20again', 1),
(56, '9118', 0, 'Manish Rai aka Maniie Raizada', '27', 'Male', 'Single', 'Chandigarh ', '1', 'Indian', '5.11 Feet', '92 Kg', 'fair', 'Brown', 'light brown', '8', 'Own business ', 'b.tech', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, punjabi', '9779730719', 'Manishurai92@gmail.com', 'Chandigarh', 'Fresher', 'Bike riding,acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919779730718', 1),
(57, '9119', 0, 'Sunita Nigam', '40yrs (on screen)', 'Female', 'Married ', 'Gurgaon Haryana ', '1', 'Indian', '5.2 Feet', '53 Kg', 'Wheatish ', 'Black ', 'Black ', '5', 'Housewife(At present)', 'Graduate', 'Day time', 'Yes', 'Yes', 'no', 'no', 'no', 'Modelling,Acting.', 'Reading books,Cooking.', 'Hindi, Bhojpuri, Haryanvi, English ', '917503061890', 'sunigam23@gmail.com', 'Gurgaon', 'Theater artist, worked in a web series, Haryanvi movie, Bollywood movie, short movie, tv serial, mytho Ramleela stage play, tvc.\r\nUpcoming Bollywood movie Rooh-Afza Directed by Hardik Mehta.', 'Acting', 'Yes', 'Yes', 'no', 'no', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:sunigam23@gmail.com?Subject=Hello%20again', 1),
(58, '9711', 0, 'Aliona', '33', 'female', 'single', 'Dubai', '5', 'Moldova ', '170 cm', '60 Kg', 'wait', 'blue ', 'wait', '39', 'manager', 'b.tech', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,trying new things , net , reading', 'English, Russian , Romanian', '+971588377278', 'alionagor87@gmail.com', 'Dubai', 'Fresher', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'mailto:alionagor87@gmail.com?Subject=Hello%20again', 1),
(59, '9712', 0, 'Adnan Mahmoud ', '26', 'Male ', 'single', 'Dubai United Arab Emirates', '5', 'Egyptian ', '175 cm', '65 Kg', 'light ', 'Brown ', 'Dark', '41', 'modeling and voiceover ', 'business administration', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, acting parting,music ,dancing,trying new things , net surfing, reading', 'English, Arabic ', '00971526854017', 'adnanmahmoud157@gmail.com', 'tecom - dubai', 'four years in modeling', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'mailto:adnanmahmoud157@gmail.com?Subject=Hello%20again', 1),
(60, '9120', 0, 'Rajesh Verma', '25', 'male', 'single', ' New Delhi', '1', 'Indian', '5.7 Feet', '60 Kg', 'fair', 'brown', 'brown', '7', 'Model', 'PG', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting', 'English, Hindi', '9891337530', 'rajeshv@ymail.com', 'UC/8A tilak nagar New Delhi', 'one year in print shoot', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/919891337530', 1),
(61, '9121', 0, 'sushant', '19', 'male', 'single', 'new delhi', '1', 'Indian', '5.9 Feet', '56 kg', 'warm ', 'black', 'black', '8', 'modeling ', 'ba. Program 2nd year', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'photography,editing', 'traveling,photography', 'English, Hindi', '8700171237', 'Sushantrajput1246@gmail.com', 'b - 854 inderpuri new delhi 110012', '3 year in photography ', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/918700171237', 1),
(62, '9122', 0, 'Barun', '28', 'male', 'single', 'Bangalore', '1', 'Indian', '5.10 Feet', '80 Kg', 'Brown', 'black', 'black', '9', 'MNC employee', 'BA', 'Any time', 'yes', 'yes', 'Yes', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, Bengali', '9002130513', 'singharoy.barun78@gmail.com', 'danahalli Gate, Bangalore', 'Fresher', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919002130513', 1),
(63, '9108100', 0, 'Shraddha', '31', 'female', 'single', 'New Delhi', '1', 'indian', '5.4 Feet', '53 Kg', 'fair', 'black', 'black nd golden', '5', 'HR', 'MBA', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi', '9354787511', 'hrshraddha101@gmail.com', 'Delhi', '3 year in Hr and 3 year experience in event management', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'mailto:hrshraddha101@gmail.com?Subject=Hello%20again', 1),
(64, '9713', 0, 'Akbar', '29', 'Male', 'Married', 'Chisinau', '5', 'Kyrgyz ', '177 Cm', '84 Kg', 'White', 'green', 'Brown', '41', 'YouTube blogger', 'Finance ', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Russian', '+37376089250', 'akbar.kudusovich@gmail.com', 'Moldova,Chisinau ', '12+ years in media', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/971501584002', 1),
(65, '9123', 0, 'Mandy BaL', '27', 'Male', 'single', 'Amritsar', '1', 'Indian', '5.11 Feet', '72 Kg', 'Fair', 'Brown', 'Brown', '8', 'Professor', 'Bca, Mca', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills', 'Fashion Show', 'English, Hindi, punjabi', '8146767190', 'mandeep12380@yahoo.in', 'Amritsar punjab', '6 Month', 'Acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919876821934', 1),
(66, '9714', 0, 'Mohammad jaffar', '26', 'male ', 'single', 'Dubai', '5', 'Syrian  ', '6.3 Feet', '90 Kg', 'fair', 'black', 'black', '44 ( Europe size )', 'model', 'b.s', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, arabic', '0508375574', 'moodja3far@gmail.com', 'dubai ', 'two year in modeling', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'no', 1),
(67, '925', 0, 'Ameer Hamza', '22', 'male', 'single', 'sindh', '2', 'Pakistani', '5.2 Feet', '48 Kg', 'fair', 'black', 'black', '4', 'model', 'B.A', 'Any time', 'yes', 'no', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, punjabi sindhi', '0340-3561056', 'ah0537013@gamil.com', 'chachar mohala Daharki', 'fresher in the field modeling and acting.. \r\n1 year in music album singing', 'Acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/923403561056', 1),
(68, '9124', 0, 'S. Sabareesh kumar', '20', 'male', 'single', 'kodaikanal, Pannaikadu', '1', 'Indian', '167 CM', '55 Kg', 'white', 'brown', 'black', '9', 'Actor', 'bsc', 'Any time', 'yes', 'no', 'yes', 'no', 'no', 'strong communicative skills, adopt to all situation', 'sports, reading, dance, music', 'Tamil, english, telugu', '6369160164', 'sabareeshkumarsdgl@gmail.com', 'kodaikanal, pannaikadu', 'short films and advertisements', 'acting ', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/916369160164', 1),
(69, '9125', 0, 'Aryan Thakur', '18', 'male', 'single', 'Ranchi', '1', 'Indian', '5.4 Feet', '48 Kg', 'fair', 'black', 'black', '7', 'photographer', '12th pass', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,photography, editing,trying new things , net surfing, reading', ' English, Hindi', '+1 (458) 212-8534', 'tommyvercity90@gmail.com', 'ranchi', 'Fresher', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/14582128534', 1),
(70, '9715', 0, 'Lexy', '22', 'Female', 'Single', 'Philippines', '5', 'Filipino', '5.5 Feet', '53 Kg', 'White', 'Black', 'Golden brown', '8', 'Receptionist', 'Business administration', 'Friday and everyday after 6', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Flexible and admirable', 'Pictorial', 'English', '971 56 978 7630', 'Lexytwotown@gmail.com', 'Lexytwotown\r\nDubai', '3 yrs photoshoot', 'Acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'mailto:Lexytwotown@gmail.com?Subject=Hello%20again', 1),
(71, '9126', 0, 'vicky', '25', 'male', 'single', 'delhi', '1', 'Indian', '5.11 Feet', '55 Kg', 'fair', 'Black', 'Black', '9', 'Student', 'mcom', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'strong communicatie skills,adopt to all situations', 'parting ,dancing,trying new things , reading', 'English, Hindi', '8375063590', 'thakurvicky062@gmail.com', 'h146 desu colony', 'Fresher', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/918375063590', 1),
(72, '276', 0, 'Thembelihle Pearl Dube', '18', 'female', 'single', 'Port Shepstone under KwaZulu-Natal', '6', 'RSA', '5.5 Feet', '63 kg', 'Fair', 'Brown', 'black', '6/7', 'Modelling', 'Diploma in Matric certificate ', 'Any time', 'Yes', 'Yes', 'no', 'no', 'no', 'well communicative advicive ', 'creative , traveling ', 'English & IsiZulu', '+27732414926', 'thembelihledube204@gmail.com', 'pobox 48 Izingolweni 4260', 'modelling', 'modelling , travelling , creating', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/27732414926', 1),
(73, '926', 0, 'Ahsan', '23', 'Male', 'single', 'faisalabad ', '2', 'Pakistani', '5.10 Feet', '60 Kg', 'medium ', 'brown ', 'dark brown ', '7', 'business ', 'brista skills and intermediate level', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing', 'English, Hindi, punjabi', '00923217817760', 'ahsansadiq553@gmail.com ', 'faisalabad canal road ', 'one year in business ', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/923117262644', 1),
(74, '9127', 0, 'Mohit Sharma', '26', 'Male', 'Single', 'Delhi', '1', 'indian', '5.8 Feet', '71 Kg', 'fair', 'Greenish', 'black', '8', 'Travelling', 'b.com', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi', '7503324245', 'mohitsai93@gmail.com', 'Wz-1452 Near by M2k Pitampura', 'Five years of exp.. in travel industry', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/917503324245', 1),
(75, '9128', 0, 'Shakthi', '24', 'Male ', 'single', 'Coimbatore ', '1', 'Indian', '5.11 Feet', '75 Kg', 'Fair', 'black', 'black', '10', 'Actor', 'B.E', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'Strong communicatie skills,adopt to all situations ', 'Traveling, Partying,music ,dancing,trying new things , net surfing, reading', 'English, tamil', '9488167123', 'shakthi.3017@gmail.com', 'Coimbatore ', 'one year in Short Film ', 'acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/919488167123', 1),
(76, '23424', 0, 'Olorunesan Oluwakemi', '20', 'Female', 'Single', 'Ibadan', '3', 'Nigeria', '5.4 Feet', '54 Kg', 'light', 'Brown', 'Brown', '40', 'caterer & Decorator', 'National Diploma ND', 'Any time', 'Yes', 'Yes', 'no', 'no', 'Yes', 'Singing, cooking, reading, meeting new people, travelling, innovating new ideas', 'Reading', 'Yoruba & English', '07060526743/09021579338', 'olorunesanoluwakemi@gmail.com', 'mber 3 papa olosan Street, alakia area Ibadan Oyo state', 'Fresher', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/2347060526743', 1),
(77, '9129', 0, 'Ramneek singh ', '21', 'male', 'single', 'delhi', '1', 'indian', '5.11 Feet', '70 Kg', 'fair', 'brown ', 'black', '9', 'model', 'b.com and event planner', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, reading, modeling', 'English, Hindi, punjabi', '9891667223', 'ramnikevent@gmail.com', 'delhi', 'one year in modeling', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919891667223', 1),
(78, '9130', 0, 'S Nadeem Basha', '23', 'Male', 'single', 'Bangalore', '1', 'indian', '5.8 Feet', '70 Kg', 'fair', 'Black', 'Black', '8', 'HR', 'B Com', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, playing games', 'English, Hindi, Telugu, kannada,Tamil', '8073736658', 'mymail.naddu@gmail.com', 'Bommanahalli', '5 years experience in HR and different field', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/918073736658', 1),
(79, '9131', 0, 'Mukesh Kumar', '19', 'Male', 'single', 'Sikar', '1', 'indian', '5.6 Feet', '52 Kg', 'Fair', 'black', 'black', '7', 'Composer', 'Diploma (Me)', 'Any time', 'yes', 'no', 'no', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'traveling,music ,reading,acting', 'English, Hindi, Haryanvi,gujrati', '9672373773,7610072826', 'devidraj226@gmail.com', '155,nagwa,nagwa,dhod,sikar, Rajasthan, 332002', 'one year in composition', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/917610072826', 1),
(80, '9716', 0, 'Mustafa ', '35', 'male', 'married ', 'Abu Dhabi', '5', 'Pakistani', '6.2 Feet', '93 Kg', 'fair', 'brown', 'black', '10', 'oil and gas company ', 'bechelor degree', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, sports reading trying new things , net surfing, reading', 'English, Hindi, punjabi', '00974561278164', 'mustafatoru86@gmail.com', 'abu dhabi', '11years in security industry  and now petrolium ', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/971561278164', 1),
(81, '927', 0, 'Moiz khan', '16', 'Male', 'Single', 'Rawalpindi', '2', 'Pakistani', '5.8 Feet', '72 Kg', 'Fair', 'Brown', 'Black', '9', 'Student', 'Matric Continue', 'any time', 'yes', 'yes', 'no', 'no', 'no', 'Adopt to all situation', 'Reading', 'Urdu, Punjabi', '92 308 8513363', 'BiGrAZaDa123@gmail.com', 'Rawalpindi ', 'Fresher', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/923088513363', 1),
(82, '9132', 0, 'Rohit', '18', 'male', 'single', 'delhi', '1', 'indian', '5.6 Feet', '48 Kg', 'fair', 'black', 'black', '7', 'Actor', '12th class', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'trying parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi', '7291947541 ', 'rohitnaagar7291@gmail.com ', 'A-3/321 nand nagri Delhi-110093', 'one year in singing', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/917291947541', 1),
(83, '2111', 0, 'Achiy', '23', 'female', 'single ', 'juba', '9', 'S Sudan', '182 cm', '45 Kg', 'bad Browne', 'Browne', 'Browne', '9', 'Student', 'Still going on', 'Any time', 'yes ', 'yes ', 'no', 'no', 'yes ', 'handle all situation', 'Reading', 'English and Arabic', '+211928807166', 'no', 'juba south Sudan ', 'Fresher', 'acting ', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/211928807166', 1),
(84, '9108101', 0, 'Isha bhargav ', '18 ', 'female ', 'single', 'hanumangarh ', '1', 'indian ', '5.3 Feet', '48 Kg', 'fair ', 'black', 'black ', '5', 'modling ', 'Still studying', 'Any time', 'yes ', 'yes ', 'no', 'no', 'no', 'strong communietie skills adopt to all situation', 'singing , dancing , traivling , listning to music , acting , modling', 'English and Hindi', '8302411243', 'no', 'sangaria ', 'Fresher', 'Acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'no', 1),
(85, '9133', 0, 'Kaushtubh Tripathi', '17', 'male', 'single', 'Kanpur', '1', 'indian', '5.7 Feet', '59 Kg', 'fair', 'brownish black', 'black', '8', 'student', '12 th Pass', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'acting,dancing,strong communication skills,adopt to all situations', 'writing,traveling, acting,dancing,literature,reading', 'English, Hindi', '9758246335', 'kaushtubhtripathi17@gmail.com', 'Kanpur', '10 years in acting and dancing', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/919758246335', 1),
(86, '9108102', 0, 'Nidhi', '21', 'female', 'single', 'Delhi', '1', 'indian', '5.7 Feet', '50 Kg', 'fair', 'brown', 'black', '6', 'Youtuber / Entrepreneur / Influencer / Tecaher', 'B.com / German till B2', '8am to 8pm', 'no', 'no', 'no', 'no', 'Yes', 'strong communicatie skills,adopt to all situations ', 'teaching  traveling,music ,dancing,trying new things , net surfing, reading', 'English, Hindi,  German', '9643430783', ' 9818love@gmail.com', 'no', 'Fresher', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:9818love@gmail.com?Subject=Hello%20again', 1),
(87, '9134', 0, 'sibi jayakumar ', '23', 'male', 'single', 'chennai ', '1', 'indian', '5.11 Feet', '85 Kg', 'fair', 'brown', 'black', '11', 'actor, model, director, writter and singer', 'b.tech', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi and tamil', '8667584511', 'sibijayakumar16@gmail.com', 'no.4 viswamithran street, muthulakshmu nagar, chitlapakam, tambaram, chennai -64', 'Fresher', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/919994169930', 1),
(88, '9135', 0, 'Luckysambi', '29', 'male', 'Married', 'Delhi ', '1', 'Indian', '5.7 Feet', '75 Kg', 'fair', 'brown ', 'black ', '7 ', 'girls hair stylist ', '12th', 'anytime', 'yes', 'yes', 'yes', 'yes', 'yes', 'Enjoy with girl dance music ', 'New new friendship karna ', 'Hindi or punjabi ', 'no', 'no', 'no', 'Fresher', 'reading', 'yes ', 'yes ', 'yes ', 'yes ', 'yes ', 'yes ', 'yes ', 'no', 'no', 'no', 'no', 'https://wa.me/919810692133', 1);
INSERT INTO `models_details` (`u_id`, `u_code`, `agency_id`, `u_name`, `u_age`, `u_gender`, `u_marital`, `u_place`, `country`, `u_nationality`, `u_height`, `u_weight`, `u_skintone`, `u_eyecolor`, `u_haircolor`, `shoesize`, `profession`, `education`, `timingfree`, `outstation`, `outsidecountry`, `seminude`, `nude`, `passport`, `skills`, `hobbies`, `language`, `number`, `email`, `address`, `experience`, `interest`, `ethenicwear`, `westernwear`, `swimsuit`, `calendershoot`, `musicalbum`, `indianwear`, `shorts`, `allergies`, `fb`, `twitter`, `instagram`, `whatsapplink`, `status`) VALUES
(89, '9136', 0, 'Sanchit Panghal', '19', 'Male', 'single', 'Delhi', '1', 'indian', '6 Feet', '80 Kg', 'fair', 'black', 'black', '10', 'Student', 'Graduation', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi', '9760577223', 'sanchitpanghal1466@gmail.com', 'Dashrathpuri Delhi', 'Fresher', 'Singing', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/919760577223', 1),
(90, '928', 0, 'ahsan Maqsood ', '17', 'male', 'single', 'sahiwal Punjab ', '2', 'Pakistani', '6 feet', '54 Kg', 'fair', 'Black', 'Black', '7', 'photoshoot', 'inter(Pre-engeering) continue ', 'Any time', 'Yes', 'Yes', 'no', 'no', 'Yes', 'adopt to all situations, hobbies, traveling, workouts, social media,study, music,poetry,quoteswriter in urdu', 'Reading', 'English,Urdu,Punjab ', '03216945201', 'no', 'no', 'Fresher', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/923067530695', 1),
(91, '9137', 0, 'Devashree MALAVIYA ', '7', 'female', 'single', 'mumbai ', 'I1', 'Indian', '4.3 Feet', '20 Kg', 'fair', 'black', 'brow ', '4', 'student', '1st class', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', ' traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, gujarati', '9819990270', 'suchitamalaviya99@gmail.com ', '503 lotus appt near aaram society behind vakola church santacruz east pincode 400055', 'Fresher', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919819990270', 1),
(92, '2301', 0, 'kajal', '17', 'female', 'singlez ', 'bramsthan ', '10', 'mauritius ', '146.5 Cm', '40 Kg', 'a little brown', 'black', 'black an red', '35', 'student', 'form 5', 'Any time', 'no', 'no', 'no', 'no', 'no', 'good  communicatie skills', 'making videoes', 'English, Hindi, french', '+23054961272', 'no', 'shivala road bramsthan mauritius', 'Fresher', 'acting', 'yes', 'yes', 'No', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/23054961272', 1),
(93, '9138', 0, 'Anubhav', '29', 'Male', 'Single', 'Delhi', '1', 'Indian', '5.9 Feet', '84 Kg', 'Fair', 'Brown', 'Brown', '9', 'Marketer', 'MBA', 'Any time', 'Yes', 'Yes', 'Yes', 'no', 'Yes', 'Strong Communication Skills ,Adapt to all situations ', 'Travelling, Socialising, Music, Dance, Exploring New ways ', 'English, Hindi', '9521315454', 'anubhav.m26@gmail.com', '191, Kavi Nagar, Ghaziabad, U.P.', 'Dancing for Shaimak, 5 years as Marketing as professional ', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919521315454', 1),
(94, '9139', 0, 'Subhankar Koley', '23', 'Male', 'Single', 'New Delhi', '1', 'Indian', '5.8 Feet', '70kg', 'Dark', 'DarkBrown', 'Black', '8', 'Student', 'BCA,B.Ed Persuing', 'Any time', 'Yes', 'No', 'No', 'No', 'No', 'Good Communicative skills,adapt to all situation,cooking,nature ', 'exploring,painting,sketching,singing,acting and dancing', 'Hindi,English and Bengali', '+91 88266 72881', 'no', 'no', 'Fresher', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/918826672881', 1),
(95, '9717', 0, 'Tosha', '23', 'female', 'single', 'Almaty', '5', 'Kazakhstan ', '1,70sm', '52 Kg', 'white', 'green', ' Brown Bright', '36', 'Civil Engeniier ', 'University and a masters degre', 'Any time', 'no', 'no', 'no', 'no', 'Yes', 'strong communicatie skills,adopt to all situations ', 'traveling, skating ,music ,dancing,trying new things , surfing, reading', ' Kaxakh(mother), Russian English', '+971 545415894', 'Suleimen1996@bk.ru', 'Al Qusais-1', 'for Jewelry shoo po mood', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:Suleimen1996@bk.ru?Subject=Hello%20again', 1),
(96, '23425', 0, 'Aderonke priceless', '17', 'female', 'Single', 'osun state', '3', 'Nigeria', '5.2 Feet', '53 Kg', 'fair', 'black', 'black', '40', 'student', ' B.tech', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'strong communicating skills, adapt to all situation', 'Dancing, traveling, singing trying new things', 'English, yoruba', '08146390692,09075390824', 'oludare4oluwalayomi@gmail.com', 'Sala adeoba''s street alekuwodo osogbo osun state', 'Fresher', 'Acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/2348146390692', 1),
(97, '23426', 0, 'Ruby abiloye', '17', 'female', 'single', 'ondo', '3', 'Nigerian', '5ft', '52Kg', 'light skinned', 'black', 'black', '42', 'student', 'finished with secondary school', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'dancing, singing n writing romantic novels', 'smiling, singing n dancing', 'Igbo, Yoruba n English', ' 08130862842,09083249813', ' funkeabiloye@gmail.com', 'number 5 abiloye street ijegun egba ,satellite town,lagos', 'Fresher', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/2348130862842', 1),
(98, '23427', 0, 'Ayobami', '18', 'female', 'single', 'Ibadan', '3', 'Nigeria', '5.3 Feet', '51 Kg', 'fair', 'black', 'black', '5', 'Student', 'jambite', 'any time', 'yes', 'yes', 'no', 'no', 'yes', 'adopt to all situation', 'traveling, trying new things, net surfing, reading', 'English and Yoruba', '09077198263', 'preciousadedoyin12@gmail.com', 'no 22 adegoke, street, orita challenge. Ibadan. Oyo state', 'Fresher', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/2349077198263', 1),
(99, '23428', 0, 'Mide', '20', 'female', 'single', 'Abeokuta ', '3', 'Nigerian', '5.8 Feet', '55 Kg', 'fair', 'black', 'black', '8', 'Entrepreneur ', 'undergraduate ', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'strong communication', 'taking pictures ,music ,dancing,trying new things , watching movies', ' English, Yoruba ', '2348156260898', 'olamideajulo2016@gmail.com', 'Abeokuta ', 'Fresher', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/2348156260898', 1),
(100, '929', 0, 'Nida', '22', 'female', 'single', 'lahore ', '2', 'Pakistani', '5.5 Feet', '57 Kg', 'fair', 'black', 'brownish ', '6', 'Model', 'b.Inter', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,  net surfing, reading', 'English, punjabi', '923454369007', 'model.nidakhan@gmail.com', 'no', 'one year in singing', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:model.nidakhan@gmail.com?Subject=Hello%20again', 1),
(101, '9108103', 0, 'Ashima Kataria', '32', 'female', 'single', 'Gurgaon', '1', 'Indian', '5.7 feet', '51 Kg', 'fair', 'black', 'black', '9', 'Fashion Stylist ', 'Fashion Designing', 'Day – Evening (Not night)', 'yes', 'Depends', 'no', 'no', 'no', 'good Communication Skill , Presentable , Confident.', 'traveling, trying new things , net surfing, designing.', 'English, Hindi.', '7065425205', 'ashi8kataria@gmail.com', 'Gurgaon (Haryana)', 'I have around 8 years exp in fashion industry (Designing +styling). Fresher in modeling startup.', 'Acting', 'yes', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'mailto:ashi8kataria@gmail.com?Subject=Hello%20again', 1),
(102, '9140', 0, 'Mukkul', '27', 'Male', 'Single', ' karnal(Haryana)', '1', 'Indian', '5.9 Feet', '72 Kg', 'Fair', 'Black', 'Black', '8', 'Business', '12th', 'Any time', 'Yes', 'Yes', 'Yes', 'no', 'no', 'Strong Communication Skills ,Adapt to all situations', 'Travelling, Socialising, Music, Exploring New ways', 'English, Hindi', '9817712383', ' mukulmony17@gmail.com', '31, Upkar Colony, karnal, Haryana', 'Fresher', 'Acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'no', 'no', 'no', 'https://wa.me/919817712383', 1),
(103, '23429', 0, 'Claire', '22', 'female', 'single', 'Abuja', '3', 'Nigerian ', '5.3 Feet', '55 Kg', 'fair', 'black', 'brown', '7', 'masseuse ', 'B.sc', 'any', 'yes', 'yes', 'yes', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'traveling,makeup,partying,music ,dancing,trying new things , net surfing, reading', 'English, Nigerian Language ', '+2348145628016', 'kachlakay@gmail.com', 'plot 101 new karmo,Abuja', 'Fresher', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/2348145628016', 1),
(104, '277', 0, 'kamogelo', '18', 'female', 'single', 'polokwane', '6', 'south Africa', '6.2 Feet', '48 Kg', 'fair', 'brown', 'brown and black', '5', 'Student', 'learner', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'Strong communicatie skills ', 'Traveling,reading,writting,dancing,cooking', 'English', '27716645074', 'no', 'no', 'Fresher', 'Acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/27716645074', 1),
(105, '9210', 0, 'Abdul ahad', '9', 'male', 'Single', 'Islamabad', '2', 'pakistani', '4.4 Feet', '42 Kg', 'fair ', 'black', 'black', '5', 'Student', 'Still studying', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'Skills strong communications', 'Music games playing many more', 'Languages urdu and English', '92 336 9276834', 'no', 'no', 'Fresher', 'Acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/923369276834', 1),
(106, '9211', 0, 'Imtiaz Ansari', '22', 'Male', 'single', 'Lahore', '2', 'Pakistani', '5.7 Feet', '58 Kg', 'fair', 'black', 'black', '8', 'Actor-Model', 'b.com', 'any Time', 'Yes', 'Yes', 'no', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', ' English, Hindi, punjabi', '+923424470547', ' imtiazansari547@gmail.com', 'Lahore Pakistan', 'one year in Struggle Actor Model', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/923414470547', 1),
(107, '9108104', 0, 'Deep Kaur', '23', 'female', 'single', 'Ludhiana', '1', 'Indian', '5.3 Feet', '47 Kg', 'fair', 'brown', 'black', '7', 'actress and model', 'pursuing MBA', 'Any time', 'yes', 'yes', 'no', 'no', 'no', 'Strong communication', 'planting,modelling', 'English, Hindi, punjabi', '9877764512', 'modeldeepkaur@gmail.com', 'ludhiana ,Punjab', 'Fresher', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'mailto:modeldeepkaur@gmail.com?Subject=Hello%20again', 1),
(108, '9108105', 0, 'parinita sharma', '11', 'Female ', 'Single ', 'Alwar rajasthan ', '1', 'Indian', '143cm', '39 Kg', 'Fair', 'Black', 'Black', '8', 'Modal ND actress child artist ', '7 class', 'Any time', 'Yes', 'Yes', 'no', 'no', 'no', 'Strong communication', 'Dancing, acting. Modling. Travelling   make \r\nTiktok vedio study playing instruments ', 'Hindi', '6378557169', 'sapnaavasthi1168@gmail.com', 'Aray anger Alwar rajasthan ', '2 years Modling ', 'Yes', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:modeldeepkaur@gmail.com?Subject=Hello%20aga...', 1),
(109, '9212', 0, 'Rana Umar', '25', 'Male', 'Single', 'Gujranwala ', '2', 'Pakistan', '5.11 Feet', '77 Kg', 'Light Skin ', 'black', 'black', '9', 'Model', 'Graduate', 'Any', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,trying new things , net surfing, reading', 'English,  urdu, punjabi', '923003819602', 'ranaumar171@gmail.com', 'D.C Road Grw. pk', 'one year in Modeling', 'Acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/923003819602', 1),
(110, '9213', 0, 'Ihsanullah ', '22', 'male', 'single', 'abu Dhabi UAE', '7', 'Pakistani ', '5.11 Feet', '66 Kg', 'fair', 'Black', 'Black', '9', 'modeling ', 'f.sc', 'any', 'yes', 'yes', 'yes', 'no', 'yes', 'nothing ', 'traveling,gym. parting,music,trying new things , reading,', 'English, Hindi, urdu pashto ', '0521882915', 'ihsan_khan4646@yahoo.com', 'uae abu Dhabi mussafah 13', 'fresher', 'acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/923480828362', 1),
(111, '9718', 0, 'Alexander (Iskander)', '23', 'male', 'single', ' Uzbekistan/Dubai', '7', 'Uzbek/Russian', '188 sm', '78 Kg', 'white', 'dark brown', 'dark brown', '42', 'model/actor/singer', 'Bachelor', 'Any time', 'yes', 'yes', 'yes', 'yes', 'yes', ' strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', ' English, Russian, Uzbek, Tadjik, Turkish, Kazak', '998935696989/ +9718768566', 'iasamandarov@gmail.com', 'Tashkent , Uzbekistan', 'one movie, singing, runways', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/971568768566', 1),
(112, '23430', 0, 'Victoria', '22', 'female', 'single', 'Osun', '3', 'Nigeria', '5.8 Feet', '58 Kg', 'fair', 'black', 'black', '7', 'dancer, fashion designer', 'ND', 'Any', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, partying,music ,dancing,trying new things , net surfing, reading', 'English', '2349056494550', 'victoriaadewuyi98@gmail.com', 'no', 'one year in acting', 'Acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/2349056494550', 1),
(113, '9141', 0, 'devesh sharma', '21', 'male', 'Single', 'Jaipur', '1', 'Indian', '5.11 feet', '72 Kg', 'fair', 'black ', 'black ', '10', 'modal', 'm.com', 'Any time', 'yes', 'yes', 'yes', 'no', 'no', 'Good communication ', ' Gyming, listening music bhajan ,reading books', 'English,Hindi, Rajasthani', '9694233668', 'deveshsharma211998@gmail.com', '397 , jp Colony sector 1 shastri Nagar Jaipur ', 'one year in modeling ', 'acting and modeling ', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919694233668', 1),
(114, '9142', 0, 'Yogesh Nagpal', '22', 'male', 'single', 'Saharanpur', '1', 'Indian', '5.6 Feet', '68 Kg', 'fair', 'black', 'black', '8', 'student', 'bachelor', 'any time', 'yes', 'yes', 'no', 'no', 'yes', 'good communicate skills,adopt to all situations ', 'traveling, parting,music ,trying new things,trekking', ' English, Hindi, punjabi, Haryanvi', '8284953366', ' shivampunjabi37@gmail.com', 'no', '2-3 Punjabi song videos', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/918284953366', 1),
(115, '278', 0, 'Nomafu', '30', 'female', 'single', 'cape town ', '6', 'South Africa', '5.4 Feet', '54 Kg', 'light brown ', 'brown ', 'black', '6', 'model and fashion design', 'grade 12', 'any time', 'yes', 'yes', 'no', 'no', 'yes', 'fashion design, modelling ', 'traveling, parting ,gym, Reading ', 'Xhosa,English ', '234763198949', 'ezakwantu1@gmail.com', ' 8936 road 31 Phillip cape town South Africa', 'fashion design', 'Acting', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/234763198949', 1),
(116, '9143', 0, 'Sairaj', '18', 'male', 'single', 'Mumbai', '1', 'indian', '5.8 Feet', '68 Kg', 'fair', 'green', 'black', '8', 'Acting', 'B.tech', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'Travelling', 'English, Hindi, Marathi ', '919511860913', 'no', 'no', 'fresher ', 'Acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919511860913', 1),
(117, '9719', 0, 'Huzair', '26', 'male', 'single', 'kashmir ', '2', 'Not mention', '5.8 Feet', '67 Kg', 'white', 'brown', 'black brownish', '42', 'model', 'b.com', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi, punjabi,urdu', '971556869732', 'huzairawan1@gmail.com', 'dubai,international city', '4 year in modeling ', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/971556869732', 1),
(118, '9720', 0, 'Mohammed Salim', '45', 'Male', 'Married', 'Dubai ', '1', 'Indian', ' 6.9 feet', '78 Kg', 'fair', 'black', 'black', '7', 'Actor, Backstage Support', 'B. Com', 'any', 'yes', 'yes', 'need discussion', 'no', 'yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading,', 'English, Hindi, Kutchi (Gujarati)', '971568156834', 'Parmar.salim@gmail.com ', 'Dubai', 'Fresher', 'acting', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/971568156834', 1),
(119, '261', 0, 'Gorataone ', '20', 'female ', 'single', 'Palapye ', '11', 'Botswana ', '1.3 Meter', '70 Kg', 'fair', 'black ', 'black ', '8', 'modeller ', 'Grade 12', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'strong communication..Adopt to all situations', 'traveling, going out, trying new things ND swimming ', 'English ND setswana', '26775596975', 'no', 'P O box 1099', '4 years in modelling ', 'Acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/26775596975', 1),
(120, '9144', 0, 'Chandan Rawat', '29', 'Male', 'Married', 'New Delhi', '1', ' Indian', '5.9 feet', '72 Kg', 'Fair', 'Dark Brown', 'Dark Brown', '8', ' Actor and Model', 'MSC IT', 'Any time', 'Yes', 'Yes', 'Yes', 'no', 'Yes', 'strong communicatie skills,adopt to all situations', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi', '91 9717588107', 'chandanrawat03@gmail.com', 'New Delhi', '1Yr in Acting and Modelling', 'Acting ', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919717588107', 1),
(121, '279', 0, 'Puleng Jacky', '25', 'Male', 'Single', 'Pretoria', '6', 'South Africa', '3.5 Feet', '52 Kg', 'Dark brown', 'Black', 'Black', '5', 'Actor and Model', 'Boilermaker', 'Any time', 'Yes', 'Yes', 'no', 'no', 'no', 'Strong communication skill,Adopt to all situations', 'Traveling,Reading and Trying new things', ' English,Sepedi,Isizulu', '27648407965', 'pulengjacky247@gmail.com', 'SK view Soshanguve\r\n0152', 'One year in Acting and Six months in Modelling', 'signing ', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/27648407965', 1),
(122, '9145', 0, 'Bhushan', '18', 'male', 'single', 'haryana', '1', 'indian', '5.11 Feet', '70 Kg', 'fair', 'black', 'black', '10', 'model', '12th ', 'any', 'yes', 'yes', 'yes', 'no', 'no', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Hindi', '917056172043', ' bhushansaini321@gmail.com', 'farrukhnagar gurgaon haryana', 'fresher', 'Acting ', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', 'no', 'https://wa.me/917056172043', 1),
(123, '9146', 0, 'Gursevak Brar ', '32', 'male', 'Married', 'Bathinda ', '1', 'indian', '5.9 Feet', '72 Kg', 'fair', 'black', 'black', '10', 'Actor,Model', 'B.A', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', ' strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,,trying new things , net surfing, reading', 'English, Hindi, punjabi', '9107200096', ' akaalbrar@gmail.com', 'Bathinda Punjab', 'Fresher', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/919107200096', 1),
(124, '2710', 0, 'Khayelihle V Ngubane', '28', 'Male', 'single', 'Durban ', '6', 'African\r\n', '5.3 Feet', '53 Kg', 'fair', 'black', 'black', '9', 'singer', 'national deploma', 'any', 'Yes', 'Yes', 'no', 'no', 'no', ' strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, zulu, xhosa', '27617903236', 'no', '119 botanic road', 'one year in singing', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/27617903236', 1),
(125, '2541', 0, 'Betty', '29', 'Female', 'single', 'Kakamega', '12', 'Kenyan', '5.9 Feet', '58 Kg', 'fair', 'white', 'black', ' 71/2', 'model', 'O''level', 'Any time', 'yes', 'yes', 'yes', 'no', 'yes', 'very good communucatie,adopt to all situations', 'travelling, singing, dancing, socializing, modeling, reading, writing,learning new things', 'English, kiswahili,luyha', '254798831359', ' bettyondino20@gmail.com', '27 Mumias', '3years in modeling', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/254798831359', 1),
(126, '9108106', 0, 'Vafia Kaur', '20 ', 'Female', 'Single ', 'Australia, Adelaide', '1', 'Indian', '5.4 Feet', '55 Kg', 'Fair', 'Brown ', 'Dark Brown', '6', 'Actress', 'Nursing ', 'Any', 'Yes', 'Yes', 'no', 'no', 'Yes', 'Good Communication Skills, Dedication', ' Acting, Making Tik Tok Videos, Cooking, Cleaning', 'Punjabi, English, and Hindi', '61 406946397', 'vafia.kaur10@gmail.com', 'Australia', 'Fresher', 'Acting ', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:vafia.kaur10@gmail.com?Subject=Hello%20aga...', 1),
(127, '2711', 0, 'Koketso ', '17', 'female', 'single', 'Johannesburg ', '6', 'south Africa', '4.4 Feet', '36 Kg', 'fair', 'black', 'black', '3', 'model', 'still in high school ', 'Any ', 'Yes', 'no', 'No', 'No', 'No', 'good communicator ', 'partying travelling ', 'English. sepedi zulu ', '27665596860', 'mashabakoketso99@gmail.com', '281tembisa mashemong sec', 'One year', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/27665596860', 1),
(128, '23431', 0, 'Rachael', '22', 'female', 'single', 'Osun', '3', 'Nigeria', '5.11 Feet', '58 Kg', 'fair', 'black', 'black', '7', 'Model', 'ND', 'Any ', 'Yes', 'Yes', 'no', 'no', 'Yes', 'strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English', '2349033107589', ' adewolerachael02@gmail.com', 'Flat3 mobile base dutse', 'one year in Modelling', 'Acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'https://wa.me/2349033107589', 1),
(129, '9108107', 0, 'sukh buttar (signy)', '25', 'female ', 'single ', 'ludhiana ', '1', 'Indian ', '5.6 Feet', '53 Kg', 'fair ', 'brown ', 'black with blonde ', 'Uk 08', 'model and singer ', 'graduate ', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', 'I was a player in pistol shooting ', 'singing and listening music ', 'English , hindi and punjabi ', '7658-021796,7658-021796', ' skaur6920@gmail.com ', 'raikot ,ludhiana ', '6/7 years in theatre ', 'acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:skaur6920@gmail.com ?Subject=Hello%20aga...', 1),
(130, '9147', 0, 'Sukhwinder Singh sidhu ', '16 ', 'male ', 'single ', 'Ghatsila Jharkhand', '1', 'Indian', '5 feet ', '48 kg ', 'fair ', 'black', 'black', '10 ', 'Student', 'Ninth standard', 'Any ', 'Yes', 'Yes', 'no', 'no', 'no', 'Dancing, acting', 'Dancing, acting, cricket, traveling', 'Hindi , Punjabi English', '9939801316', 'singhsukwhinder@gmail.com', 'Near light house laldhi Ghatsila, jharkhand', 'No ', 'acting ', 'yes ', 'yes ', 'no ', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/9939801316', 1),
(131, '9148', 0, 'Praveen Kumar', '30', 'Male', 'single', 'Bangalore', '1', 'Indian', '5.11 Feet', '75 Kg', 'Mid white', 'black', 'black', '10', 'Salaried', 'B.sc', 'Any time', 'yes', 'yes', 'no', 'no', 'yes', ' strong communicatie skills,adopt to all situations ', 'traveling, parting,music ,dancing,trying new things , net surfing, reading', 'English, Tamil, Teulgu, Kannada', '8884028276', 'pravi.pvp04@gmail.com', '#8, 1 st main ,1 cross , Vinayaka Nagar , Banglore', 'Fresher', 'Acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'https://wa.me/8884028276', 1),
(132, '9149', 0, 'Kanishk', '25', 'Male', 'Single', 'Delhi ', '1', 'Indian', '5.95', '67kg', 'fair', 'dark brown', 'black', '8', 'Marketing Manager ', 'Graduate', 'Any time', 'no', 'no', 'no', 'no', 'yes', 'strong communication skills, adaptable to work with various kind of people', 'Playing cricket, basketball, ListeningMusic, PC gaming', 'English, Hindi', '9810992923', 'ksharma0594@gmail.com', 'Hari Nagar,Delhi', 'Modelling for about 6months', 'acting', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'mailto:ksharma0594@gmail.com ?Subject=Hello%20aga...', 1),
(133, '9150', 0, 'Vinod kumar ', '21', 'Male', 'single', 'Bangalore ', '1', 'Indian', '5.7 Feet', '70 Kg', 'asian', 'Black', 'Black', '8', 'Actor and model', 'Graduate', 'Any time', 'yes', 'yes', 'yes', 'yes', 'yes', 'strong communicatie skills,adopt to all situations and quick learner', ' parting, music ,dancing, net surfing', 'English, Hindi, Tamil, Kannada', '9066141823', 'mastarvino@gmail.com', '#37, 1st A cross 2nd main Cambridge layout Halasuru Bangalore', 'Fresher', 'Acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:mastarvino@gmail.com?Subject=Hello%20aga...', 1),
(134, '9108108', 0, 'Subodhini Arekar ( Subu)    ', '30', 'Female', 'Single', 'Mumbai', '1', 'Indian', '5.5. Feet', '45 Kgs', 'Fair', 'black', 'black', '8', 'Model ,Actor ,Anchor', 'Graduate', 'any', 'Yes', 'Yes', 'no', 'no', 'Yes', 'Acting,singing', 'Plantation,reading', 'English Hindi Marathi Gujarati learning Japanese and Italian', '8454898203                       ', 'subumodelprofile@yahoo.com      ', 'Mumbai', ':( above 8 Years ) Started with Ramp and Print Commercials and YouTube Hosting .     \r\n\r\n\r\n   1) Currently shot with Bollywoodz Ace photographer Rajesh Gopinath under Agency DYT for "Adonia jewelries"', 'Acting', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:subumodelprofile@yahoo.com?Subject=Hello%20aga...', 1),
(135, '9151', 0, 'Guru', '33', 'male', 'Married', 'Nashik', '1', 'Indian', '5.8 Feet', '68 Kg', 'fair', 'Black', 'Black', '8', 'Anchor & Actor', 'b.com', 'any', 'yes', 'yes', 'no', 'no', 'yes', 'strong communication skills,adopt to all situations ', 'traveling,music ,dancing, net surfing, cricket', 'English, Hindi, sindhi, marathi', '9272424245 / 9226252406', 'guruhariyani@gmail.com', 'Nashik', '7 year in Anchoring & 2.5 years in acting', 'acting', 'Yes', 'Yes', 'no', 'Yes', 'Yes', 'Yes', 'Yes', 'no', 'no', 'no', 'no', 'mailto:guruhariyani@gmail.com?Subject=Hello%20aga...', 1),
(136, '9108109', 0, 'Manisha das', '22', 'female', 'single', 'Kolkata ', '1', 'Indian', '5.3 Feet', '50 Kg', 'fair', 'black', 'black', '7', 'student', 'b.A', '8:00am to 5:00pm', 'no', 'no', 'Yes', 'Yes', 'no', 'Acting', 'music, reading', 'Hindi, Bengali', '6290777781', 'dasrimpa825@gmail.com', 'shibpur Howrah', 'Fresher', 'Listening music', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'mailto:dasrimpa825@gmail.com?Subject=Hello%20aga...', 1);

-- --------------------------------------------------------

--
-- Table structure for table `requirem`
--

CREATE TABLE IF NOT EXISTS `requirem` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_name` varchar(200) NOT NULL,
  `r_number` varchar(200) NOT NULL,
  `r_production` varchar(200) NOT NULL,
  `r_director` varchar(200) NOT NULL,
  `r_producer` varchar(200) NOT NULL,
  `pay` varchar(200) NOT NULL,
  `ourrate` varchar(200) NOT NULL,
  `commission` varchar(2000) NOT NULL,
  `location` varchar(200) NOT NULL,
  `r_desc` varchar(5000) NOT NULL,
  `r_date` date NOT NULL,
  `r_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`r_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `requirem`
--

INSERT INTO `requirem` (`r_id`, `r_name`, `r_number`, `r_production`, `r_director`, `r_producer`, `pay`, `ourrate`, `commission`, `location`, `r_desc`, `r_date`, `r_status`) VALUES
(1, 'Taha Rao', '923040276028', 'Mr Handsome Production', 'Taha Rao', 'Saim mirza', '', '', '', 'Pakistan', 'I have a production house in Pakistan nd models required for brand shoot and fashion show in Pakistan', '2020-06-19', 0),
(2, 'shoaib ahmed', '+923452793328', 'modeling ', 'shoaib', 'any', '', '', '', '', 'meiny modling karni hay isliye apply kiya hay ', '2020-06-20', 0),
(3, 'Pankaj mishra', '9971355530', 'No', 'no', 'no', '', '', '', 'India', 'Photo shoot  Moti Nagar t-shirt suit', '2020-06-20', 0),
(4, 'Deepak phogat', '7037531100', 'Mor music ', 'Amit bharu', 'Uttar kumar', '', '', '', '', 'Hi this is Deepak phogat 30 years old .i M a ranji cricket player frm up . I M available for all kinds of shoots on 10k to 50k per day according to location and work', '2020-06-20', 0),
(5, 'Vivek saxena', '+918755481983', 'TBD', 'TBD', 'TBD', '7k-8k', '5000 per day per model', '1k per day', 'Delhi/Noida', 'Hello Models ! Looking for 3 Female Models of India Origin for a webseries shoot will start in July End. Location is Delhi and Noida. Models/Actresses should be comfortable with bold scenes. ', '2020-06-20', 1),
(6, 'Lokesh', '+919599102549', 'Artist junction', 'Lokesh', 'Lokesh', '15000 per day', '10000 per day', '1k per day', 'Delhi', 'Big brand shoot ', '2020-06-20', 0),
(7, 'Pratik Bhattacharya', '+919609920236', 'Mp production', 'Pratik bhattacharya', 'Partik bhattacharya', '10000/day', '5000 per day', '1k per day', 'Kolkata', '90 days shooting need a female model 19-25 age for foreign project.\r\n<br>\r\nDress off,seminude shoot is there.\r\n<br>\r\nSelection on basis of-<br>\r\n&nbsp&nbsp&nbsp Sending normal photos <br>\r\n&nbsp&nbsp&nbsp Sending normal pics<br>', '2020-06-20', 1),
(8, 'Sandeep', '9001092208', 'chitchat', 'chitchat', 'chitchat', '150 ', '70 ten minute work', '30', 'Work from home', 'All you need is know punjabi read and speak this is one time work if you agree then connect with me.', '2020-06-20', 0),
(9, 'Arjun singh', '+917400170431', 'AVA FILMS AND ENTERTAINMENT', 'Jeetendra Singh Gill', 'Arjun Singh', '5000', '5000/Day', 'no', 'Delhi', 'Required 2 Female Actress or artist \r\n<br>who will interested for bold and nudity concept for balaji ALT WEBSERIES female should we attractive figure bold look age 20 to 25 toll.<br> \r\n5 day shoot.\r\n', '2020-06-21', 1),
(10, 'Ransh Model coordinator', '91 6239581465', 'Kamerock production', 'Himankar Ajnabi', 'Jass maan', 'For 10 day 25k ', '', '', '', 'We hire  Girl for Movie (wardaat) In main lead. For bold Shoot. ', '2020-06-21', 0),
(11, 'Rockey', '7507814717', 'Fashion arts film', 'Sameer Khan', 'Sameer Khan', '6000/day 5 days shoot', '4000/Day', '1000/day', 'Mumbai', 'Webseries bold content Require 3 Females From bombay \r\n<br> Accomodation by Production\r\n<br> Cab available within Mumbai\r\n<br> Height - 5.4 Above\r\n<br>4-5 day shoot.', '2020-06-21', 1),
(12, 'Vinay Kumar Maurya', '+917267025863', 'Studio law', 'Manoharan jayapal', 'Manohar', '25000 ', '10000/day', '1000/day', 'Banglore and Mumbai', 'Urgent requirement for e-commerce and catalogue shoot in Bangalore nd Mumbai for bikni n lingerie shoot  10 female model required shoot  will be on July first week or second week\r\nModel look slim and tall good looking with proper figure\r\n30 changes per day and pay  25 k per model, Two days of shoot for each model . Travel ,food accommodation provided by the client...\r\nInterested model can send Ur recent pictures.\r\nVkmaurya\r\n+917267025863', '2020-06-21', 1),
(13, 'Sarmad shahzad', '+923059982174', 'I dont know', 'I dont know', 'Nill', 'I dont know', '', '', '', 'Im fresher i want to become model', '2020-06-21', 0),
(14, 'hamza tariq', '+923354966542', 'For YouTube channel', 'Hamza tariq', 'Non', '20000 pkr', '20000 pkr Daily', 'No', 'Pakistan', 'I need a girl for my YouTube channel. My channel is gaming channel. And i need a charming and attractive girl.\r\n\r\nWho can spent 10-15 minute on playing pubg. Nedd 3 videos daily', '2020-06-21', 1),
(15, 'hamza tariq', '+923354966542', 'For YouTube channel', 'Hamza tariq', 'Non', '20000 pkr', '', '', '', 'I need a girl for my YouTube channel. My channel is gaming channel. And i need a charming and attractive girl.', '2020-06-21', 0),
(16, 'Sandeep', '9001092208', 'rdtfgh', 'dfgh', 'dfgh', '1761987', '', '', '', 'ghjcvbngvbn                                           ', '2020-06-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `suggestion`
--

CREATE TABLE IF NOT EXISTS `suggestion` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `suggest_jobid` int(11) NOT NULL,
  `suggest_agencyid` int(11) NOT NULL,
  `suggest_modelid` int(11) NOT NULL,
  `suggest_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `suggestion`
--

INSERT INTO `suggestion` (`s_id`, `suggest_jobid`, `suggest_agencyid`, `suggest_modelid`, `suggest_status`) VALUES
(1, 16, 0, 2341, 3),
(2, 16, 0, 271, 2);
